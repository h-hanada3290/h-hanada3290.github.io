            for row in results:
                session_id, session_data_bytes = row
                
                # データ型が'memoryview'の場合、bytes型に変換 (データベースによっては不要)
                if isinstance(session_data_bytes, memoryview):
                    session_data_bytes = bytes(session_data_bytes)
                
                if not session_data_bytes:
                    print(f"--- セッションID: {session_id} はデータが空です ---")
                    continue

                try:
                    # msgpackでデコードしてPythonの辞書に変換
                    session_dict = msgpack.unpackb(session_data_bytes, raw=False)
                    
                    # --- ★ 修正箇所：辞書全体を出力する ---
                    print(f"\n==============================================")
                    print(f"  セッションID: {session_id}")
                    print(f"==============================================")
                    
                    # JSON形式で整形して出力
                    # indent=2 で見やすく、ensure_ascii=False で日本語もそのまま表示
                    print(json.dumps(session_dict, indent=2, ensure_ascii=False))
                    
                    # デバッグ用の補助情報
                    print("-" * 40)
                    if 'tab_uuid' in session_dict:
                        print(f"  [UUID確認] tab_uuid: {session_dict['tab_uuid']}")
                    if 'locks' in session_dict:
                        print(f"  [ロック情報] キー数: {len(session_dict.get('locks', {}).get('keys', []))}")
                    print("-" * 40)
                    # ------------------------------------

                except Exception as e:
                    print(f"セッションデータのデコードエラー (セッションID: {session_id}): {e}")
