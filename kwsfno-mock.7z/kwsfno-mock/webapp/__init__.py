from flask import Flask
import os

app = Flask(__name__)
app.config.from_object('webapp.config')

from webapp.views import views