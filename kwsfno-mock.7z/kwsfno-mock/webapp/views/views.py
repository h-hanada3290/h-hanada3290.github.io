from flask import request, redirect, url_for, render_template, flash, session
from webapp import app
from webapp.lib.utils import get_processing_category, get_display_title
import random

@app.route('/')
def top():
    """トップ画面表示"""
    num1 = 999
    num2 = 9999
    num3 = 99999
    num4 = 9
    return render_template('top.html', num1=num1, num2=num2, num3=num3, num4=num4)

@app.route('/login')
def login():
    """ログイン画面表示"""
    return render_template('login.html')

@app.route('/status_list')
def status_list():
    """処理状況一覧画面表示"""
    # 検索結果を取得


    return render_template('status_list.html')

@app.route('/status_list_by_user')
def status_list_by_user():
    """処理状況一覧画面表示"""
    # 検索結果を取得

    return render_template('status_list_user.html')


@app.route('/inquiry')
def inquiry():

    """ 受信票初鑑画面のモックアップ """
    # タイトルをコントロールする変数
    display_title_index = str(request.args.get('title'))

    # 処理区分を制御する変数
    processing_category_index= str(request.args.get('processing_category'))
    
    # タイトル
    title = get_display_title(display_title_index)
    abstract_dict = {}
    # 受信票種別
    abstract_dict['choice'] = request.args.get('name')
    # 摘要1の値
    abstract_dict['abstract1'] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    # 摘要2の値
    abstract_dict['abstract2'] = "BBBBBBBB-CCCCCCCCCCCCC.DDDDDDDDDDDDDDDD"
    # 摘要3の値
    abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
    # 摘要4の値
    abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    # 照会番号
    reference_number = 123456789012345
    # 処理区分リストを取得。
    processing_category_dict = get_processing_category()
    # 処理区分リストから初期表示される区分を取得。
    selected_processing_category = processing_category_dict[processing_category_index]
    # 処理区分リストから初期表示される区分を削除。
    del processing_category_dict[processing_category_index]
    return render_template('inquiry.html',
                           title=title,
                           abstract_dict=abstract_dict,
                           reference_number=reference_number,
                           processing_category_dict=processing_category_dict,
                           selected_processing_category=selected_processing_category
                           )

@app.route('/re_inquiry')
def re_inquiry():

    """ 受信票再鑑画面のモックアップ """
    # タイトルをコントロールする変数
    display_title_index = str(request.args.get('title'))

    # 処理区分を制御する変数
    processing_category_index= str(request.args.get('processing_category'))
    
    # タイトル
    title = get_display_title(display_title_index)
    abstract_dict = {}
    # 受信票種別
    abstract_dict['choice'] = request.args.get('name')
    # 摘要1の値
    abstract_dict['abstract1'] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    # 摘要2の値
    abstract_dict['abstract2'] = "BBBBBBBB-CCCCCCCCCCCCC.DDDDDDDDDDDDDDDD"
    # 摘要3の値
    abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
    # 摘要4の値
    abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    # 照会番号
    reference_number = 123456789012345
    # 処理区分リストを取得。
    processing_category_dict = get_processing_category()
    # 処理区分リストから初期表示される区分を取得。
    selected_processing_category = processing_category_dict[processing_category_index]
    # 処理区分リストから初期表示される区分を削除。
    del processing_category_dict[processing_category_index]
    return render_template('re_inquiry.html',
                           title=title,
                           abstract_dict=abstract_dict,
                           reference_number=reference_number,
                           processing_category_dict=processing_category_dict,
                           selected_processing_category=selected_processing_category
                           )

# @app.route('/re_inquiry')
# def re_inquiry():
#     """ 受信票再鑑画面のモックアップ """
#     title="受信票再鑑"
#     abstract_dict = {}
#     #受信票種別
#     abstract_dict['choice'] = "normal"
#     print(abstract_dict)
#     # 摘要1の値
#     abstract_dict['abstract1'] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
#     # 摘要2の値
#     abstract_dict['abstract2'] = "BBBBBBBB-CCCCCCCCCCCCC.DDDDDDDDDDDDDDDD"
#     # 摘要3の値
#     abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
#     # 摘要4の値
#     abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
#     # 照会番号
#     reference_number = 123456789012345
#     processing_category_dict = get_processing_category()
#     selected_processing_category = processing_category_dict['01']
#     del processing_category_dict['01']
#     return render_template('re_inquiry.html',
#                            title=title,
#                            abstract_dict=abstract_dict,
#                            reference_number=reference_number,
#                            processing_category_dict=processing_category_dict,
#                            selected_processing_category=selected_processing_category
#                            )

# @app.route('/re_replacement')
# def re_replacement():
#     """ 受信票再鑑付替画面のモックアップ """
#     title="受信票再鑑付替"
#     abstract_dict = {}
#     #受信票種別
#     abstract_dict['choice'] = "replace"
#     # 摘要1の値
#     abstract_dict['abstract1'] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
#     # 摘要2の値
#     abstract_dict['abstract2'] = "11111111111111111111111111111111111111111111111111111"
#     # 摘要3の値
#     abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
#     # 摘要4の値
#     abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
#     # 照会番号
#     reference_number = 123456789012345
#     processing_category_dict = get_processing_category()
#     selected_processing_category = processing_category_dict['07']
#     return render_template('re_inquiry.html',
#                            title=title,
#                            abstract_dict=abstract_dict,
#                            reference_number=reference_number,
#                            processing_category_dict=processing_category_dict,
#                            selected_processing_category=selected_processing_category
#                            )

# @app.route('/re_prior_error')
# def re_prior_error():
#     """ 受信票再鑑事前エラー画面のモックアップ """
#     title="受信票再鑑事前エラー"
#     abstract_dict = {}
#     #受信票種別
#     abstract_dict['choice'] = "error"
#     # 摘要1の値
#     abstract_dict['abstract1'] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
#     # 摘要2の値
#     abstract_dict['abstract2'] = "11111111111111111111111111111111111111111111111111111"
#     # 摘要3の値
#     abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
#     # 摘要4の値
#     abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
#     # 照会番号
#     reference_number = 123456789012345
#     processing_category_dict = get_processing_category()
#     selected_processing_category = processing_category_dict['02']
#     return render_template('re_inquiry.html',
#                            title=title,
#                            abstract_dict=abstract_dict,
#                            reference_number=reference_number,
#                            processing_category_dict=processing_category_dict,
#                            selected_processing_category=selected_processing_category
#                            )


@app.route('/receipt_search_sending')
def receipt_search_sending():
    """受信票明細検索（仕向）"""
    status_list = ['受信票初鑑'
                   ,'受信票初鑑保留'
                   ,'受信票再鑑'
                   ,'受信票再鑑保留'
                   ,'回答待ち'
                   ,'回答なし'
                   ,'送信エラー'
                   ,'回答初鑑確認'
                   ,'回答初鑑保留'
                   ,'回答再鑑確認'
                   ,'回答再鑑待ち保留'
                   ,'QR作成待ち'
                   ,'BCP対処'
                   ,'完了'
                   ]
    
    flg_list    = ['フラグなし'
                   ,'給与・賞与'
                   ,'優先'
                   ,'不備'
                   ,'オペミス'
                   ,'オペミス確認済'
                   ,'異例取引'
                   ]
    
    classification_list = ['振込不能照会'
                           ,'事前エラー'
                           ,'照会無回答による資金返却'
                           ,'ダイレクト資金返却'
                           ,'ダイレクト資金返却(照会不要分)'
                           ,'組戻依頼の資金返却'
                           ,'次回より訂正'
                           ,'連絡先照会'
                           ,'特殊先等の資金返却(照会不要分)'
                           ,'破棄電文(請求電文)'
                           ,'破棄電文(正当電文)'
                           ,'破棄電文(破棄のみ)'
                           ,'目視確認要'
                           ,'目視確認要(破棄)'
                           ]
    return render_template('receipt_search_sending.html',
                           status_list=status_list,
                           flg_list=flg_list,
                           classification_list=classification_list
                           )

@app.route('/receipt_search_results_sending')
def receipt_search_results_sending():
    """受信票明細検索結果一覧"""
    return render_template('receipt_search_results_sending.html')

@app.route('/receipt_details_sending')
def receipt_details_sending():
    """受信票明細"""
    flg_list    = ['給与'
                   ,'オペミス'
                   ,'破棄'                   
                   ,'総振'
                   ,'回答無効化'
                   ,'破棄対象'
                   ,'優先'
                   ,'回答なし'
                   ,'破棄済'
                   ,'不備'
                   ,'再回答なし'
                   ]
    return render_template('receipt_details_sending.html', flg_list=flg_list)

@app.route('/receipt_search_receiving')
def receipt_search_receiving():
    """" 受信票明細検索（被仕向） """
    return render_template('receipt_search_receiving.html')


@app.route('/contractor_search')
def contractor_search():
    """ 契約先情報検索 """
    status_list = ['全て'
                   ,'更新予定全て'
                   ,'開始日待ち'
                   ,'本登録'
                   ,'仮登録'
                   ,'仮変更'
                   ,'削除申請中'
                   ,'削除済'
                   ,'テストメール送信待ち'
                   ,'テストメール受信待ち'
                   ]
    return render_template('contractor_search.html', status_list=status_list)

@app.route('/contractor_search_results')
def contractor_search_results():
    """ 契約先情報検索結果一覧 """
    return render_template('contractor_search_results.html')

@app.route('/contractor_details')
def contractor_details():
    """" 契約先情報詳細 """
    return render_template('contractor_details.html')

@app.route('/answer_appraisal')
def answer_appraisal():
    answer_type_list = ["change","transfer","return"]
    abstract_dict = {}
    abstract_dict['choice'] = random.choice(answer_type_list)
    # 摘要1の値
    abstract_dict['abstract1'] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    # 摘要2の値
    abstract_dict['abstract2'] = "NNNNNNN NNNNN"
    # 摘要3の値
    abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
    # 摘要4の値
    abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    return render_template('answer_appraisal.html', abstract_dict=abstract_dict)

@app.route('/re_answer_appraisal')
def re_answer_appraisal():
    answer_type_list = ["change","transfer","return"]
    abstract_dict = {}
    abstract_dict['choice'] = random.choice(answer_type_list)
    # 摘要1の値
    abstract_dict['abstract1'] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    # 摘要2の値
    abstract_dict['abstract2'] = "NNNNNNN NNNNN"
    # 摘要3の値
    abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
    # 摘要4の値
    abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    return render_template('re_answer_appraisal.html', abstract_dict=abstract_dict)

@app.route('/contractor_registration')
def contractor_registration():
    """" 契約先情報登録 """
    title = "契約先情報登録"
    button = "仮登録"
    return render_template('contractor_register_change.html', title=title, button = button)

@app.route('/contractor_modification')
def contractor_modification():
    """" 契約先情報変更 """
    title = "契約先情報変更"
    button = "仮変更"
    return render_template('contractor_register_change.html', title=title, button = button)

@app.route('/user_list')
def user_list():
    """" ユーザー情報一覧 """
    title = "ユーザー情報一覧"
    return render_template('user_list.html', title=title)

@app.route('/user_detail')
def user_detail():
    """" ユーザー情報詳細 """
    title = "ユーザー情報詳細"
    return render_template('user_detail.html', title=title)

@app.route('/user_modify')
def user_modify():
    """" ユーザー情報変更 """
    title = "ユーザー情報一覧"
    return render_template('user_modify.html', title=title)

@app.route('/user_register')
def user_register():
    """" ユーザー情報登録 """
    title = "ユーザー情報一覧"
    return render_template('user_register.html', title=title)

@app.route('/password_change')
def password_change():
    """" パスワード変更 """
    title = "パスワード変更"
    return render_template('password_change.html', title=title)

@app.route('/password_reset')
def password_reset():
    """" パスワード初期化 """
    title = "パスワード初期化"
    return render_template('password_reset.html', title=title)


@app.route('/receipt_search_sending_not_destination')
def receipt_search_sending_not_destination():
    """受信票明細検索(仕向以外)"""
    title = "受信票明細検索(仕向以外)"
    return render_template('receipt_search_sending_not_destination.html', title=title)

@app.route('/receipt_search_results_sending_not_destination')
def receipt_search_results_sending_not_destination():
    """受信票明細検索結果一覧(仕向以外)"""
    return render_template('receipt_search_results_sending_not_destination.html')

@app.route('/receipt_details_sending_not_destination')
def receipt_details_sending_not_destination():
    """受信票明細(仕向以外)"""
    return render_template('receipt_details_sending_not_destination.html')

@app.route('/mail_list')
def mail_list():
    """" メール送受信一覧 """
    title = "メール送受信一覧"
    return render_template('mail_list.html', title=title)

@app.route('/mail_answer_list')
def mail_answer_list():
    """" 回答依頼書送受信一覧 """
    title = "回答依頼書送受信一覧"
    return render_template('mail_answer_list.html', title=title)

@app.route('/mail_detail')
def mail_detail():
    """" メール詳細 """
    title = "メール詳細"
    return render_template('mail_detail.html', title=title)


# 破棄はその他の初鑑と統合されるためコメントアウトしています。不必要が確定次第、削除
# @app.route('/revocation')
# def revocation():
#     """" 破棄初鑑 """
#     btn_hidden = True
#     return render_template('revocation.html', btn_hidden=btn_hidden)

@app.route('/consumption_tax_rate')
def consumption_tax_rate():
    abstract_dict = {}
    # 摘要1の値
    abstract_dict['abstract1'] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    # 摘要2の値
    abstract_dict['abstract2'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    # 摘要3の値
    abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
    # 摘要4の値
    abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    return render_template('consumption_tax_rate.html', abstract_dict=abstract_dict)

@app.route('/commission')
def commission():
    abstract_dict = {}
    # 摘要1の値
    abstract_dict['abstract1'] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    # 摘要2の値
    abstract_dict['abstract2'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    # 摘要3の値
    abstract_dict['abstract3'] = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉ"
    # 摘要4の値
    abstract_dict['abstract4'] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    return render_template('commission.html', abstract_dict=abstract_dict)

@app.route('/operation_log')
def operation_log():
    """操作ログ照会画面表示"""

    # 検索結果を取得

    return render_template('operation_log.html')
