$(document).ready(function() {
    // ステータス一覧画面の検索ボタン押下
    $('#status-list-search').on('click', function() {
        // Check which radio button is selected
        const isStatusByUser = $('#status-list-status-by-user').is(':checked');
        console.log(isStatusByUser)

        // Redirect to the Flask route with parameters
        let url = '/Prod/';
        if (isStatusByUser) {
            url += 'status_list_by_user';
        } else {
            url += 'status_list';
        }

        // Perform the redirection
        window.location.href = url;
    });


    // ユーザ別一覧画面の検索ボタン押下
    $('#status-list-user-search').on('click', function() {
        // Check which radio button is selected
        const isStatusListUserAllStatus = $('#status-list-user-all-status').is(':checked');
        console.log(isStatusListUserAllStatus)

        // Redirect to the Flask route with parameters
        let url = '/Prod/';
        if (isStatusListUserAllStatus) {
            url += 'status_list';
        } else {
            url += 'status_list_by_user';
        }

        // Perform the redirection
        window.location.href = url;
    });

    // ステータス一覧画面のユーザ別を選択時
    function toggleInputAllState() {
        const inputField = $('#status-list-sales-department');
        if ($('#status-list-status-by-user').is(':checked')) {
            inputField.val('');  // Clear the input field value
            $('#status-list-sales-department').prop('disabled', true);
        } else {
            $('#status-list-sales-department').prop('disabled', false);
        }
    }

    // Initial check on page load
    toggleInputAllState();

    // Attach event listeners to radio buttons
    $('input[name="all-status-radio"]').on('change', function() {
        toggleInputAllState();
    });


    // ユーザ別一覧画面のユーザ別を選択時
    function toggleInputUserState() {
        const inputField = $('#status-list-user-sales-department');
        if ($('#status-list-user-status-by-user').is(':checked')) {
            inputField.val('');  // Clear the input field value
            $('#status-list-user-sales-department').prop('disabled', true);
        } else {
            $('#status-list-user-sales-department').prop('disabled', false);
        }
    }

    // Initial check on page load
    toggleInputUserState();

    // Attach event listeners to radio buttons
    $('input[name="user-status-radio"]').on('change', function() {
        toggleInputUserState();
    });
});