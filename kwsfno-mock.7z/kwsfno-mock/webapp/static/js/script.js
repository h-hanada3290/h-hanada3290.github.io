

/** 摘要欄を修正した際に修正前を表示する関数 */
function beforeModificationDisplay(id_name) {
    // const input_element = document.getElementById(element_name);
    const row_element = document.getElementById(id_name+"-th");
    const before_element = document.getElementById("before-"+id_name);    
    row_element.setAttribute("rowSpan", "2")
    before_element.style.display = '';
}

/** チェックボックストグル */
function ToggleChecked(target_check){
    let all_check = document.getElementsByName(target_check);
    for(let i = 0; i < all_check.length; i++){
        if (all_check[i].value.endsWith("_all")) {
          if (all_check[i].checked) {
            AllChecked(target_check);
          } else {
            AllUnChecked(target_check);
          }
        }
    }
}


/** チェックボックス全選択 */
function AllChecked(target_check){
    let all_check = document.getElementsByName(target_check);
    for(let i = 0; i < all_check.length; i++){
        all_check[i].checked = true;
    }
}
  
/** チェックボックス全解除 */
function AllUnChecked(target_check){
    let all_check = document.getElementsByName(target_check);
    for(let i = 0; i < all_check.length; i++){
        all_check[i].checked = false;
    }
}

function forReceiptDetails(url) {
    location.href=url;
}


/** モーダル */
// const myModal = document.getElementById('myModal')
// const myInput = document.getElementById('myInput')

// myModal.addEventListener('shown.bs.modal', () => {
//   myInput.focus()
// })

function radioEnabledEvent(target_name) {
    console.log(target_name)
    let radios = document.querySelectorAll('[name=radio-client-name1]');
    console.log(radios)
    Array.from(radios).forEach(function(r){
        console.log(r)
        r.addEventListener('click', function(){
          let priceA = document.getElementById('price-a');
          let priceB = document.getElementById('price-b');
          let priceC = document.getElementById('price-c');
          let priceD = document.getElementById('price-d');

          console.log(r)

          if(this.id == 'the-next-day'){
            priceA.removeAttribute('disabled')
            priceB.removeAttribute('disabled')
            priceC.removeAttribute('disabled')
            priceD.removeAttribute('disabled')
          }
          else{
            priceA.setAttribute('disabled', 'disabled');
            priceB.setAttribute('disabled', 'disabled');
            priceC.setAttribute('disabled', 'disabled');
            priceD.setAttribute('disabled', 'disabled');
          }
        });
      });
}

/**テーブル行全体をリンク化 */
document.addEventListener('DOMContentLoaded', function() {
  var rows = document.querySelectorAll('.clickable-row');

  rows.forEach(function(row) {
    // CSSのカーソルをポインタに設定
    row.style.cursor = 'pointer';

    row.addEventListener('mouseover', function() {
      row.style.backgroundColor='#f0f0f0';
    });

    // クリックイベントを設定
    row.addEventListener('click', function() {
      var href = row.getAttribute('data-href');
      if (href) {
        window.location.href = href;
      }
    });

    
  });
});

/**パスワード表示・非表示アイコン */
document.addEventListener('DOMContentLoaded', function () {
  var viewicon = document.getElementById('view');
  var inputtype = document.getElementById('file_password');
  
  viewicon.addEventListener('click', function () {
      if (inputtype.type === 'password') {
          inputtype.type = 'text';
          viewicon.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
          inputtype.type = 'password';
          viewicon.innerHTML = '<i class="far fa-eye"></i>';
      }
  });
});

/**  照会電文の管理番号 モーダルだし分け処理*/
function inquirySSBtnEvent() {

  /* 照会電文の管理番号のinput **/
  let inquiry_input = document.getElementById('inquiry_control_number');

  /* 受信票紐づけ検索モーダル **/
  const jyushin_link_search_modal = new bootstrap.Modal(document.getElementById('jyushin-link-search-modal'));
  /* 付替対象モーダル **/
  const replace_items_modal = new bootstrap.Modal(document.getElementById('replace-items-Modal'));


  if(!inquiry_input.value){
    jyushin_link_search_modal.show()
  }else{
    replace_items_modal.show()
  }

}

/**  破棄対象の管理番号 モーダルだし分け処理*/
function removeSSBtnEvent() {

  /* 破棄対象の管理番号のinput **/
  let remove_input = document.getElementById('remove_control_number');

  /* 受信票紐づけ検索モーダル **/
  const jyushin_link_search_modal = new bootstrap.Modal(document.getElementById('jyushin-link-search-modal'));
  /* 破棄対象モーダル **/
  const replace_items_modal = new bootstrap.Modal(document.getElementById('remove-items-Modal'));


  if(!remove_input.value){
    jyushin_link_search_modal.show()
  }else{
    replace_items_modal.show()
  }

}

/**　受信票初鑑・再鑑の表示だし分け　
 * 処理区分：破棄の場合
*/
function inquiryChangeProcessingBtnEvent() {
  /* 処理区分のselect **/
  let processing = document.getElementById('inquiryProcessingControlSelect');
  let selected_value = processing.value

  const btn = document.getElementById('inpuGroup')

  console.log(btn)

  remove_list=["11","12","13","15"]

  if(remove_list.includes(selected_value)){
    if(btn.classList.contains("d-none")){
      btn.classList.toggle("d-none")
    }
  }else{
    if(!btn.classList.contains("d-none")){
      btn.classList.toggle("d-none")
    }
  }
}

/**　受信票初鑑・再鑑 チェック判定文字色分け
 * 異例取引チェック
 * チェック：赤色 チェック無し：黒色
*/
function inquiryCheckBoxColorChanged(checkBoxName, labelName) {
  
  let checked_box = document.getElementById(checkBoxName)
  let checked_label = document.getElementById(labelName)

  if(checked_box.checked == true){
    checked_label.parentNode.style.color = 'red';
  }else{
    checked_label.parentNode.style.color = '#333333';//文字色
  }

}
