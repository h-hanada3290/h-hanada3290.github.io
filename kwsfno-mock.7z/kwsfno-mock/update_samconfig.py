import toml
import os

# 環境変数からスタック名を取得
stack_name = os.getenv('STACK_NAME')

# samconfig.toml を読み込む
with open('samconfig.toml', 'r') as f:
    samconfig = toml.load(f)

# stack_name を更新
samconfig['default']['deploy']['parameters']['stack_name'] = stack_name

# 更新された設定を samconfig.toml に書き込む
with open('samconfig.toml', 'w') as f:
    toml.dump(samconfig, f)
