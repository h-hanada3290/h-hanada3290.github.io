from webapp import app
import awsgi

def handler(event, context):
    event['headers']['X-Forwarded-Prefix'] = "/" + event['requestContext']['stage']
    def wrap_app(environ, sr):
        environ['SCRIPT_NAME'] = "/" + event['requestContext']['stage']
        return app(environ, sr)
    return awsgi.response(wrap_app, event, context)

