/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：メール送受信テーブル（mail_soujyusin_table）
//  概要		：メール送受信を管理するテーブル
//  更新日時	：2025/05/21　⇒　2025/6/12 垣内が更新しました。(center_no追加)
//  			  2025/07/11 11:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.27反映
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS mail_soujyusin_table;
CREATE TABLE mail_soujyusin_table (
	mail_soujyushin_no				 			VARCHAR(36),							/* メール送受信番号(36) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	soujyushin_flag								TEXT,									/* 送受信フラグ (1) */
	soujyushin_time								TIMESTAMP,								/* 送受信時間(14) */
	"to"										TEXT,									/* TO(512) */
	cc											TEXT,									/* CC(512) */
	mail_title									TEXT,									/* 件名(64) */
	mail_honbun									TEXT,									/* メール本文(4,000) */
	soushinsha									TEXT,									/* 送信者(32) */
	torihikisaki_no								TEXT,									/* 送信テスト-取引先番号(11) */
	status_code									TEXT,									/* ステータスコード(2) */
	shubetsu									TEXT,									/* 種別(2) */
	mail_id										TEXT,									/* メールID(512) */
	tmp_count									TEXT,									/* 添付ファイル数(2) */
	update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 	/* システム更新日時(17) */
	CONSTRAINT mail_soujyusin_table_pkc PRIMARY KEY (mail_soujyushin_no, center_no)
);
COMMENT ON TABLE mail_soujyusin_table IS 'メール送受信テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：メール内容テーブル（mail_template_table）
//  概要          ：メール内容を管理するテーブル
//  更新日時      ：2025/05/21
//                  2025.07.27 PRIMARY KEY追加 花田
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS mail_template_table;
CREATE TABLE mail_template_table (
	mail_naiyo_no							VARCHAR(6) PRIMARY KEY,					/* メール内容番号(6) */
	gyomu									TEXT,									/* 業務(2) */
	center_no								VARCHAR(6),								/* センター番号(6) */
	syori_kbn_code							TEXT,									/* 処理区分コード(2) */
	mail_title								TEXT,									/* 件名(64) */
	honbun									TEXT,									/* 本文(500) */
	template_1								TEXT,									/* テンプレート１(500) */
	template_2								TEXT,									/* テンプレート２(500) */
	template_3								TEXT,									/* テンプレート３(500) */
	template_4								TEXT,									/* テンプレート４(500) */
	template_5								TEXT,									/* テンプレート５(500) */
	template_6								TEXT,									/* テンプレート６(500) */
	template_7								TEXT,									/* テンプレート７(500) */
	template_8								TEXT,									/* テンプレート８(500) */
	template_9								TEXT,									/* テンプレート９(500) */
	template_10								TEXT,									/* テンプレート１０(500) */
	template_11								TEXT,									/* テンプレート１１(500) */
	template_12								TEXT,									/* テンプレート１２(500) */
	template_13								TEXT,									/* テンプレート１３(500) */
	template_14								TEXT,									/* テンプレート１４(500) */
	system_insert_datetime					TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime					TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE mail_template_table IS 'メール内容テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：メール不備テーブル（mail_hubi_table）
//  概要          ：メール不備を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS mail_hubi_table;
CREATE TABLE mail_hubi_table (
	hubi_no										VARCHAR(36),							/* 不備番号(36) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	mail_soujyushin_no							VARCHAR(36),							/* メール送受信番号(36) */
	status_code									TEXT,									/* ステータスコード(2) */
	hubi_flag									TEXT,									/* 不備フラグ(2) */
	tmp_file_no									TEXT,									/* 添付ファイル番号(36) */
	update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT mail_hubi_table_pkc PRIMARY KEY (hubi_no, center_no)
);
COMMENT ON TABLE mail_hubi_table IS 'メール不備テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：ユーザ情報テーブル（user_info_table）
//  概要          ：ユーザ情報を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS user_info_table;
CREATE TABLE user_info_table (
	user_id										VARCHAR(8),								/* ユーザID(8) */
	center_no									VARCHAR(6),								/* エリアセンター番号(6) */
	role_no										VARCHAR(4),								/* 権限(4) */
	user_name									TEXT,									/* ユーザ名(32) */
	user_name_kana								TEXT,									/* ユーザ名（カナ）(32) */
	lapse_info									TEXT,									/* 失効情報(32) */
	password									TEXT,									/* パスワード(128) */
	id_insert_date								DATE,									/* ID登録日(8) */
	id_remove_date								DATE,									/* ID削除日(8)*/
	last_login_date								DATE,									/* 最終ログイン日(8) */
	lock_flag									TEXT,									/* ロックフラグ(1) */
	failure_count								INTEGER,								/* 失敗カウント */
	reset_flag									TEXT,									/* 初期化フラグ(8) */
	password_update_datetime					TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* パスワード変更日時(17) */
	update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT user_info_table_pkc PRIMARY KEY (user_id, center_no, role_no)
);COMMENT ON TABLE user_info_table IS 'ユーザ情報テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：印刷シーケンステーブル（insatsu_seq_table）
//  概要		：印刷シーケンスを管理するテーブル
//  key_columu	：固定値「"jushin"：受信票用、
//                          "qr_tsu"：QR通信用、"qr_nyu"：QR入金用、"qr_shi"：QR仕向振込用、"qr_chu"：中間勘定用、
//                          "qr_bny"：QR別段入金用、"qr_bsh"：QR別段支払用」
//  更新日時	：2025/06/18
//  			  2025/07/2  13:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.25反映
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS insatsu_seq_table;
CREATE TABLE insatsu_seq_table (
	key_columu									VARCHAR(6),								/* キー項目(6) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	jushin_seq									INTEGER,								/* 受信票シーケンス(7) */
	qr_seq_tsuushin								INTEGER,								/* QRシーケンス_通信(7) */
	qr_seq_nyuukin								INTEGER,								/* QRシーケンス_入金(7) */
	qr_seq_shimukefurikomi						INTEGER,								/* QRシーケンス_仕向振込(7) */
	qr_seq_chuukankanjou						INTEGER,								/* QRシーケンス_中間勘定(7) */
	qr_seq_betsudannyuukin						INTEGER,								/* QRシーケンス_別段入金(7) */
	qr_seq_betsudanshiharai						INTEGER,								/* QRシーケンス_別段支払(7) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT insatsu_seq_table_pkc PRIMARY KEY (key_columu, center_no)
);
COMMENT ON TABLE insatsu_seq_table IS '印刷シーケンステーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名		：印刷通番テーブル（insatsu_tsuban_table）
//  概要			：印刷通番を管理するテーブル
//  更新日時		：2025/05/21
//                    2025/08/12 修正ミス：NOT NULL漏れを追加。
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS insatsu_tsuban_table;
CREATE TABLE insatsu_tsuban_table (
	numbering_key								VARCHAR(15) PRIMARY KEY,				/* ナンバリングキー(15) */
	jushinhyo_pdf_print_no						TEXT NOT NULL,							/* 受信票PDF印刷番号(23) */
	qr_pdf_print_no_tsuushin					TEXT NOT NULL,							/* QR_PDF印刷番号_通信(23) */
	qr_pdf_print_no_nyuukin						TEXT NOT NULL,							/* QR_PDF印刷番号_入金(23) */
	qr_pdf_print_no_shimukefurikomi				TEXT NOT NULL,							/* QR_PDF印刷番号_仕向振込(23) */
	qr_pdf_print_no_chuukankanjou				TEXT NOT NULL,							/* QR_PDF印刷番号_中間勘定(23) */
	qr_pdf_print_no_betsudannyuukin				TEXT NOT NULL,							/* QR_PDF印刷番号_別段入金(23) */
	qr_pdf_print_no_betsudanshihara				TEXT NOT NULL,							/* QR_PDF印刷番号_別段支払(23) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE insatsu_tsuban_table IS '印刷通番テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：運用部署テーブル（unyo_busho_table）
//  概要		：運用部署を管理するテーブル
//  更新日時	：2025/07/18 PK カラム名の間違いを修正
//                2025/07/29 データベース設計Rev1.32対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS unyo_busho_table;
CREATE TABLE unyo_busho_table (
	center_no									VARCHAR(6) PRIMARY KEY,					/* センター番号(6) */
	kyoten_office_name							TEXT,									/* 拠点名称(50) */
	kyoten_tel_no								TEXT,									/* 電話番号(16) */
	kyoten_mail_user_id							TEXT,									/* メールユーザID(50) */
	kyoten_mail_address							TEXT,									/* メールアドレス(50) */
	kyoten_password								TEXT,									/* パスワード(128) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE unyo_busho_table IS '運用部署テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：営業日一覧テーブル（eigyo_bi_table）
//  概要          ：営業日を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS eigyo_bi_table;
CREATE TABLE eigyo_bi_table (
	eigyo_date									DATE PRIMARY KEY,						/* 営業年月日(8) */
	honbu_update_date							DATE,									/* 本部分析更新日(8) */
	update_status								TEXT,									/* 更新ステータス(1) */
	update_check								TEXT,									/* 更新チェック(1) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE eigyo_bi_table IS '営業日一覧テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：画面テーブル（page_table）
//  概要          ：画面の権限、URL、画面名を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS page_table;
CREATE TABLE page_table (
	page_id										VARCHAR(6) PRIMARY KEY,					/* 権限(6) */
	page_url									TEXT,									/* 権限名(50) */
	gamen_name									TEXT,					  				/* 画面名(256) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);

COMMENT ON TABLE page_table IS '画面テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：回答依頼書テーブル（answer_request_table）
//  概要		：回答依頼書を管理するテーブル
//  更新日時	：2025/03/25 09:00→2025/05/19 11:13 キムが更新しました。→2025/06/13 11:50 高岸が更新しました。
//  			  2025/07/11 11:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.26反映
//                2025/07/29 データベース設計Rev1.32対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS answer_request_table;
CREATE TABLE answer_request_table (
	answer_request_no							VARCHAR(15),							/* 回答依頼番号(15) */
	edaban										INTEGER,								/* 枝番(2) */
	numbering_key								TEXT,									/* ナンバリングキー(15) */
	receive_mail_date							TIMESTAMP,								/* メール受信日時(14) */
	company_name								TEXT,									/* 社名(120) */
	guest_person_charge							TEXT,									/* お客様担当者名(120) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	shubetsu									TEXT,									/* 種別(1) */
	henko_recipient_name						TEXT,									/* 変更-お受取人名義(カナ・アルファベット)(100) */
	henko_payee_type							TEXT,									/* 変更-預金種目(4) */
	henko_payee_type_code						TEXT,									/* 変更-預金種目コード(3) */
	henko_payee_account_num						TEXT,									/* 変更-口座番号(7) */
	kouzahenkyaku_payee_type					TEXT,									/* 口座返却-預金種目(4) */
	kouzahenkyaku_payee_type_code				TEXT, 									/* 口座返却-預金種目コード(3) */
	kouzahenkyaku_payee_account_num				TEXT,									/* 口座返却-口座番号(7) */
	kouzahenkyaku_biko							TEXT,									/* 口座返却-備考(4) */
	saihurikomi_financial_institution			TEXT,									/* 再振込-金融機関(15) */
	saihurikomi_financial_institution_code		TEXT,									/* 再振込-金融機関コード(4) */
	saihurikomi_siten							TEXT,									/* 再振込-支店(15) */
	saihurikomi_siten_code						TEXT,									/* 再振込-支店コード(4) */
	saihurikomi_payee_type						TEXT,									/* 再振込-預金種目(4) */
	saihurikomi_payee_type_code					TEXT,									/* 再振込-預金種目コード(3) */
	saihurikomi_payee_account_num				TEXT,									/* 再振込-口座番号(7) */
	saihurikomi_recipient_name					TEXT,									/* 再振込-お受取人名義(カナ・アルファベット)(100) */
	status_code									TEXT,									/* ステータスコード(2) */
	renrakujiko									TEXT,									/* 連絡事項(100) */
	update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT answer_request_table_pkc PRIMARY KEY (answer_request_no, edaban)
);
COMMENT ON TABLE answer_request_table IS '回答依頼書テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：規定手数料テーブル（kitei_tesuryo_table）
//  概要          ：規定手数料を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS kitei_tesuryo_table;
CREATE TABLE IF NOT EXISTS kitei_tesuryo_table (
    tekiyo_kaishi_date							DATE PRIMARY KEY,						/* 適用開始年月日(10)（"9999/12/31"固定） */
    henko_tesuryo								INTEGER,								/* 変更手数料(6) */
    kumimodoshi_tesuryo_koza_henkyaku			INTEGER,								/* 組戻手数料（口座返却）(6) */
    kumimodoshi_tesuryo_sai_furikomi			INTEGER,								/* 組戻手数料（再振込(6)） */
    update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE kitei_tesuryo_table IS '規定手数料テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：金融機関支店マスタ（bank_branch_master）
//  概要          ：金融機関支店を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS bank_branch_master;
CREATE TABLE bank_branch_master (
	bank_cd										VARCHAR(4),								/* ＜４桁＞銀行コード(4) */
	branch_cd									VARCHAR(4),					  			/* ＜４桁＞支店コード(4) */
	bank_name									TEXT,									/* ＜１５桁＞銀行名(15) */
	kana_bank_name								TEXT,					  				/* ＜１５桁＞カナ銀行名(15) */
	branch_name									TEXT,					  				/* ＜１５桁＞支店名(15) */
	kana_branch_name							TEXT,					  				/* ＜１５桁＞カナ支店名(15) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT bank_branch_master_pkc PRIMARY KEY (bank_cd, branch_cd)
);
COMMENT ON TABLE bank_branch_master IS '金融機関支店マスタ';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：権限テーブル（role_table）
//  概要          ：ユーザの権限を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS role_table;
CREATE TABLE role_table (
    role_no										VARCHAR(4) PRIMARY KEY,					/* 権限(4) */
    role_name									TEXT,									/* 権限名(50) */
    jurisdiction_code							TEXT,									/* 管理コード(1) */
    policy										JSON,									/* ポリシー(1,000) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);

COMMENT ON TABLE role_table IS '権限テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：仕分テーブル（shiwake_table）
//  概要		：受信票の仕分け条件を管理するテーブル
//  更新日時	：2025/05/21
//                2025/07/29 データベース設計Rev1.34対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS shiwake_table;
CREATE TABLE shiwake_table (
	jimu_kanri_buten_code						VARCHAR(6),								/* 事務管理部店コード(6) */
	shiwake_no									VARCHAR(2),								/* 仕分no(2) */
	tsushin_shumoku_from						TEXT,					  				/* 通信種目from(4) */
	tsushin_shumoku_to							TEXT,						  			/* 通信種目to(4) */
	shiwake_kbn									TEXT,					  				/* 仕分区分(1) */
	syori_kbn_code								TEXT,					  				/* 処理区分コード(2) */
	tekiyou_mozi								TEXT,					  				/* 摘要文字(53) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT shiwake_table_pkc PRIMARY KEY (jimu_kanri_buten_code, shiwake_no)
);
COMMENT ON TABLE shiwake_table IS '仕分テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：取引先情報テーブル（torihikisaki_jyouhou_table）
//  概要		：取引先を管理するテーブル
//  更新日時	：2025/05/21 09:33　柳井健志　削除日を追加
//                2025/07/29 データベース設計Rev1.32対応
//                2025/09/08 データベース設計Rev1.36対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS torihikisaki_jyouhou_table;
CREATE TABLE torihikisaki_jyouhou_table (
	torihikisaki_no								VARCHAR(11),							/* 取引先番号(11) */
	hontoroku_kubun								VARCHAR(1),								/* 本登録区分(1) */
	kaishi_date									DATE,									/* 開始日(8) */
	uketsuke_date								DATE,									/* 受付日(8) */
	torihikisaki_status							TEXT,									/* 取引先ステータス(2) */
	torihikisaki_name							TEXT,									/* 取引先名(120) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	eigyo_buten_code							TEXT,									/* 営業部店コード(4) */
	cif											TEXT,									/* CIF(10) */
	furikomi_kbn								TEXT,									/* 振込区分(8) */
	jiko_tsugou_kbn								TEXT,									/* 自己都合区分(2) */
	tokushu_atsuka_saki							TEXT,									/* 特殊扱先(1) */
	tesuryo_shuno_kbn							TEXT,									/* 手数料収納区分(1) */
	henko_tesuryo								TEXT,									/* 変更手数料(6) */
	henko_tesuryo_biko							TEXT,									/* 変更手数料備考(20) */
	kumimodoshi_tesuryo_koza_henkyaku			TEXT,									/* 組戻手数料（口座返却）(6) */
	kumimodoshi_tesuryo_koza_henkyaku_biko		TEXT,									/* 組戻手数料（口座返却）(20)備考 */
	kumimodoshi_tesuryo_sai_furikomi			TEXT,									/* 組戻手数料（再振込）(6) */
	kumimodoshi_tesuryo_sai_furikomi_biko		TEXT,									/* 組戻手数料（再振込）(20)備考 */
	nyukin_koza_shumoku							TEXT,									/* 入金口座種目(3) */
	nyukin_koza_no								TEXT,									/* 入金口座番号(7) */
	daihyo_tel_no								TEXT,									/* 代表電話番号(16) */
	daiko_keiyaku_kbn							TEXT,									/* 代行契約区分(32) */
	daiko_keiyaku_moto							TEXT,									/* 代行契約元(11) */
	irainin_name_kana							TEXT,									/* 依頼人名（カナ）(48) */
	chui_kanki_level							TEXT,									/* 注意喚起レベル(1) */
	tempu_file_password							TEXT,									/* 添付ファイルパスワード(24) */
	biko										TEXT,									/* 備考(400) */
	delete_date									DATE,									/* 削除日(8) */
	update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT torihikisaki_jyouhou_table_pkc PRIMARY KEY (torihikisaki_no, hontoroku_kubun)
);
COMMENT ON TABLE torihikisaki_jyouhou_table IS '取引先情報テーブル';

/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：取引先担当者テーブル（torihikisaki_tantosha_table）
//  概要		：取引先担当者を管理するテーブル
//  更新日時	：2025/05/21 09:33　柳井健志　削除日を追加
//                2025/07/29 データベース設計Rev1.33対応（まで確認済み）
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS torihikisaki_tantosha_table;
CREATE TABLE torihikisaki_tantosha_table (
	torihikisaki_no								TEXT,									/* 取引先番号(11) */
	tantosha_id									INTEGER,								/* 担当者ID(14) */
	hontoroku_kubun								VARCHAR(1),								/* 本登録区分(1) */
	to_atesaki									TEXT,									/* To(宛先)(1) */
	tantosha_name								TEXT,									/* 担当者氏名(120) */
	tantosha_name_kana							TEXT,									/* 担当者氏名（カナ）(120) */
	tantosha_tel_no								TEXT,									/* 担当者電話番号(16) */
	mail_address								TEXT,									/* メールアドレス(50) */
	soshin_test_status							TEXT,									/* 送信テストステータス(10) */
	delete_date									DATE,									/* 削除日(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT torihikisaki_tantosha_table_pkc PRIMARY KEY (torihikisaki_no, tantosha_id, hontoroku_kubun)
);
COMMENT ON TABLE torihikisaki_tantosha_table IS '取引先担当者テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：受信店・センターテーブル（jushinten_center_table）
//  概要		：受信店とセンターを管理するテーブル
//  更新日時	：2025/06/18
//                2025/09/29 データベース設計Rev1.37対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jushinten_center_table;
CREATE TABLE jushinten_center_table (
	jushinten_no								VARCHAR(4),								/* 受信店番号(4) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	jushinten_name								TEXT,									/* 受信店名(13) */
	jushinten_name_kana							TEXT,									/* 受信店名（カナ）(15) */
	center_name									TEXT,									/* センター名(13) */
	center_name_kana							TEXT,									/* センター名（カナ）(15) */
	tengun_zokusei_code							VARCHAR(2),								/* 店群属性コード(2) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT jushinten_center_table_pkc PRIMARY KEY (jushinten_no, center_no)
);
COMMENT ON TABLE jushinten_center_table IS '受信店・センターテーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：受信店マスタ（jushinten_table）
//  概要		：受信店を管理するテーブル
//  更新日時	：2025/07/2
//  			  2025/07/2  13:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.25反映
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jushinten_table;
CREATE TABLE jushinten_table(
  jushinten_no												VARCHAR(4) PRIMARY KEY,					/* 受信店番号(4) */
  jushinten_name											TEXT,									/* 受信店名(13) */
  jushinten_name_kana										TEXT,									/* 受信店名（カナ）(15) */
  system_insert_datetime									TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
  system_update_datetime									TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE jushinten_table IS '受信店マスタ';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：受信票テーブル（jushinhyo_table）
//  概要		：受信票を管理するテーブル
//  更新日時	：2025/05/02 14:00→2025/05/13 11:53 花田がカラムをそろえて直しました。
//  			  2025/07/2  13:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.25反映
//  			  2025/07/11 11:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.28反映
//                2025/07/29 データベース設計Rev1.32対応
//                2025/08/08 データベース設計Rev1.34対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jushinhyo_table;
CREATE TABLE jushinhyo_table (
	numbering_key								VARCHAR(15) PRIMARY KEY,				/* 1.ナンバリングキー(15) */
	insert_date_time							DATE,									/* 2.登録日時(14) */
	jushin_renkei_data_ichiren_no_7				TEXT NOT NULL,							/* 3.受信票連携データ格納＜７桁＞一連番号(7) */
	shori_taisho_entity_code					TEXT NOT NULL,							/* 4.処理対象エンティティ識別コード(4) */
	torihiki_code								TEXT NOT NULL,							/* 5.取引識別コード(8) */
	shohin_service_code							TEXT NOT NULL,							/* 6.商品サービスコード(10) */
	delayed_logical_path_id_no					TEXT NOT NULL,							/* 7.ディレイド論理パスＩＤ番号(3) */
	delayed_logical_path_tsu_no					TEXT NOT NULL,							/* 8.ディレイド論理パス通番(15) */
	toriatsukai_date							DATE,									/* 9.取扱年月日(8) */
	toriatsukai_time							TEXT NOT NULL,							/* 10.取扱時刻(9) */
	delayed_seizon_message_info_code			TEXT NOT NULL,							/* 11.ディレイド生存通知メッセージ情報コード(1) */
	delayed_keihyo_output_buten_code			TEXT NOT NULL,							/* 12.ディレイド計表出力先事務管理部店コード(6) */
	jushin_insatsu_yusen_hiyusen_flag			TEXT NOT NULL,							/* 13.受信票印刷優先／非優先フラグ(2) */
	konai_terminal_message_id_no				TEXT NOT NULL,							/* 14.行内業務端末宛メッセージＩＤ番号(9) */
	tsushin_shumoku_code_4						TEXT NOT NULL,							/* 15.＜４桁＞通信種目コード(4) */
	jushin_sai_output_flag						TEXT NOT NULL,							/* 16.受信票再出力有無フラグ(1) */
	zengin_kurikoshi_hyoji						TEXT NOT NULL,							/* 17.全銀繰越表示(1) */
	zenjitsu_saisou_flag						TEXT NOT NULL,							/* 18.前日再送フラグ(1) */
	kawase_jushin_no_15							TEXT NOT NULL,							/* 19.＜１５桁＞為替受信番号(15) */
	jushinten_code_4							TEXT NOT NULL,							/* 20.＜４桁＞受信店コード(4) */
	jushinten_torihiki_ten_hojo_code			TEXT NOT NULL,							/* 21.受信店取引店補助コード(2) */
	jiten_jushin_output_buten_code				TEXT NOT NULL,							/* 22.自店受信票出力先事務管理部店コード(6) */
	denbun_jushin_date							DATE,									/* 23.電文受信年月日(8) */
	denbun_jushin_time_9						TEXT NOT NULL,							/* 24.＜９桁＞電文受信時刻(9) */
	shimuke_bank_code_4							TEXT NOT NULL,							/* 25.＜４桁＞仕向銀行コード(4) */
	kana_shimuke_bank_name_15					TEXT NOT NULL,							/* 26.＜１５桁＞カナ仕向銀行名(15) */
	shimuke_shiten_code_4						TEXT NOT NULL,							/* 27.＜４桁＞仕向支店コード(4) */
	kana_shimuke_shiten_name_15					TEXT NOT NULL,							/* 28.＜１５桁＞カナ仕向支店名(15) */
	naitame_output_terminal_buten_code			TEXT NOT NULL,							/* 29.＜内為出力＞端末設定事務管理部店コード(6) */
	jimu_kanri_buten_code						TEXT NOT NULL,							/* 30.事務管理部店コード(6) */
	naitame_torihiki_date						DATE,									/* 31.内為取引年月日(8) */
	tsushin_shumoku_code_42						TEXT NOT NULL,							/* 32.＜４桁＞通信種目コード2(4) */
	kawase_fuka_code							TEXT NOT NULL,							/* 33.＜為替＞付加コード(3) */
	naitame_torihiki_kingaku					NUMERIC(15) NOT NULL,					/* 34.内為取引金額(15) */
	zenjitsu_flag								TEXT NOT NULL,							/* 35.前日フラグ(1) */
	kisan_flag									TEXT NOT NULL,							/* 36.起算フラグ(1) */
	kanjo_date									DATE,									/* 37.勘定日(8) */
	kisan_date									DATE,									/* 38.起算日(8) */
	nyukinsaki_yokin_kamoku_code				TEXT NOT NULL,							/* 39.入金先預金科目コード(3) */
	nyukinsaki_koza_no							TEXT NOT NULL,							/* 40.入金先口座番号(7) */
	dai1_kana_tekiyo_info_48					TEXT NOT NULL,							/* 41.第１＜４８桁＞カナ摘要情報(48) */
	dai2_kana_tekiyo_info_48					TEXT NOT NULL,							/* 42.第２＜４８桁＞カナ摘要情報(48) */
	dai3_kana_tekiyo_info_48					TEXT NOT NULL,							/* 43.第３＜４８桁＞カナ摘要情報(48) */
	dai4_kana_tekiyo_info_48					TEXT NOT NULL,							/* 44.第４＜４８桁＞カナ摘要情報(48) */
	kana_edi_info_20							TEXT NOT NULL,							/* 45.＜２０桁＞カナＥＤＩ情報(20) */
	oguchi_uketuke_num_15						TEXT NOT NULL,							/* 46.＜半角英数／１５桁＞大口受付番号(15) */
	tsushin_shumokubetsu_no_info				TEXT NOT NULL,							/* 47.通信種目別番号情報(16) */
	furikae_tatenken_umu_flag					TEXT NOT NULL,							/* 48.振替他店券有無フラグ(1) */
	dai1_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 49.第１振替他店券入金額(18) */
	dai2_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 50.第２振替他店券入金額(18) */
	dai3_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 51.第３振替他店券入金額(18) */
	dai4_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 52.第４振替他店券入金額(18) */
	rendou_nyukin_flag							TEXT NOT NULL,							/* 53.連動入金フラグ(1) */
	nyukin_funo_jiyu_code_2						TEXT NOT NULL,							/* 54.＜２桁＞入金不能事由コード(2) */
	torihiki_seigen_code_6						TEXT NOT NULL,							/* 55.＜６桁＞取引制限コード(6) */
	naitame_master_tsuchi_flag					TEXT NOT NULL,							/* 56.内為マスター通知通知要フラグ(1) */
	koza_kana_meiginin_name						TEXT NOT NULL,							/* 57.口座カナ名義人名(48) */
	kawase_hasshin_no_15						TEXT NOT NULL,							/* 58.＜１５桁＞為替発信番号(15) */
	kawase_shokai_no_15							TEXT NOT NULL,							/* 59.＜１５桁＞為替照会番号(15) */
	zengin_center_shori_time					TEXT NOT NULL,							/* 60.全銀センター処理時刻(6) */
	zengin_center_shori_no						TEXT NOT NULL,							/* 61.全銀センター処理番号(8) */
	kawase_hirendou_ko_no						TEXT NOT NULL,							/* 62.為替非連動口番号(7) */
	mokuteki_betsudan_meisai_no					TEXT NOT NULL,							/* 63.目的別別段明細番号(10) */
	chukan_kanjo_no								TEXT NOT NULL,							/* 64.中間勘定番号(10) */
	kawase_torihiki_soshin_op_id_no				TEXT NOT NULL,							/* 65.為替取引送信オペレーターＩＤ番号(10) */
	hishimuke_ten_code_4						TEXT NOT NULL,							/* 66.＜４桁＞被仕向店コード(4) */
	kana_hishimuke_ten_name_15					TEXT NOT NULL,							/* 67.＜１５桁＞カナ被仕向店名(15) */
	furikomi_uketorinin_yokin_kamoku_code		TEXT NOT NULL,							/* 68.振込受取人預金科目コード(3) */
	koza_no_15									TEXT NOT NULL,							/* 69.＜１５桁＞口座番号(15) */
	kasoten_hasshin_no_15						TEXT NOT NULL,							/* 70.仮想店＜１５桁＞発信番号(15) */
	kasoten_tensou_shimuke_bank_code_4			TEXT NOT NULL,							/* 71.仮想店転送情報＜４桁＞仕向銀行コード(4) */
	kasoten_tensou_kana_shimuke_bank_name_15	TEXT NOT NULL,							/* 72.仮想店転送情報＜１５桁＞カナ仕向銀行名(15) */
	kasoten_tensou_shimuke_ten_code_4			TEXT NOT NULL,							/* 73.仮想店転送情報＜４桁＞仕向店コード(4) */
	kasoten_tensou_kana_shimuke_ten_name_15		TEXT NOT NULL,							/* 74.仮想店転送情報＜１５桁＞カナ仕向店名(15) */
	saifurikomi_naitame_kamoku_code				TEXT NOT NULL,							/* 75.再振込元電文内為科目コード(3) */
	saifurikomi_koza_no_7						TEXT NOT NULL,							/* 76.再振込元電文＜英数字／７桁＞口座番号(7) */
	kawase_toritate_no_6						TEXT NOT NULL,							/* 77.＜為替＞＜６桁＞取立番号(6) */
	fuwatari_code_1								TEXT NOT NULL,							/* 78.＜１桁＞不渡コード(1) */
	shikin_shurui_code							TEXT NOT NULL,							/* 79.資金種類コード(5) */
	furikomihyo_tegata_kensu					TEXT NOT NULL,							/* 80.振込票／手形件数(5) */
	torikumi_no_6								TEXT NOT NULL,							/* 81.＜半角英数／６桁＞取組番号(6) */
	jushin_henshu_kubun_code					TEXT NOT NULL,							/* 82.受信票編集区分コード(1) */
	naitame_tsushin_torihiki_kingaku			TEXT NOT NULL,							/* 83.内為通信取引金額(15) */
	denbun_keshikomi_jokyo_code					TEXT NOT NULL,							/* 84.電文消込状況コード(1) */
	gyomu_error_code							TEXT NOT NULL,							/* 85.業務エラーコード(9) */
	oguchi_naitame_torikeshi_flag				TEXT NOT NULL,							/* 86.大口内為取消フラグ(1) */
	jushin_zengin_error_gyomu_error_code		TEXT NOT NULL,							/* 87.受信票全銀エラー固有部業務エラーコード(9) */
	kana_zengin_format_meisai_info_1			TEXT NOT NULL,							/* 88.＜１行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_2			TEXT NOT NULL,							/* 89.＜２行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_3			TEXT NOT NULL,							/* 90.＜３行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_4			TEXT NOT NULL,							/* 91.＜４行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_9			TEXT NOT NULL,							/* 92.＜９行目＞カナ全銀フォーマット明細情報(48) */
	shiwa_kbn									TEXT NOT NULL,							/* 93.仕分区分(1) */
	syori_kbn_code								TEXT NOT NULL,							/* 94.処理区分コード(2) */
	status_code									TEXT NOT NULL,							/* 95.ステータスコード(2) */
	op_miss_kakuninyou_flag						TEXT NOT NULL,							/* 96.オペミス確認要フラグ(1) */
	op_miss_kakuninzumi_flag					TEXT NOT NULL,							/* 97.オペミス確認済フラグ(1) */
	kyuyo_flag									TEXT NOT NULL,							/* 98.給与フラグ(1) */
	yusen_flag									TEXT NOT NULL,							/* 99.優先フラグ(1) */
	fubi_flag									TEXT NOT NULL,							/* 100.不備フラグ(1) */
	ireitorihiki_flag							TEXT NOT NULL,							/* 101.異例取引フラグ(1) */
	tekiyo_1_moto								TEXT NOT NULL,							/* 102.摘要１元(48) */
	tekiyo_2_moto								TEXT NOT NULL,							/* 103.摘要２元(48) */
	tekiyo_3_moto								TEXT NOT NULL,							/* 104.摘要３元(48) */
	tekiyo_4_moto								TEXT NOT NULL,							/* 105.摘要４元(48) */
	shokai_no_moto								TEXT NOT NULL,							/* 106.照会番号元(15) */
	kanri_no_moto_tuke							TEXT NOT NULL,							/* 107.管理番号元-付替(512) */
	kanri_no_moto_haki							TEXT NOT NULL,							/* 108.管理番号元-破棄(512) */
	renrakujiko1								TEXT NOT NULL,							/* 109.連絡事項①(100) */
	renrakujiko2								TEXT NOT NULL,							/* 110.連絡事項②(50) */
	eigyobuten									TEXT NOT NULL,							/* 111.営業部店(4) */
	irainin_name_kana							TEXT NOT NULL,							/* 112.依頼人名（カナ）(48) */
	torihikisaki_no								VARCHAR(11) NOT NULL,					/* 113.取引先番号(11) */
	cifsaki_torihikisaki_no						VARCHAR(11) NOT NULL,					/* 114.CIF先取引先番号(11) */
	kaito_iraisyo_syurui						TEXT NOT NULL,							/* 115.回答依頼書種類(1) */
	jizen_error_file1							TEXT NOT NULL,							/* 116.事前エラー添付ファイル１(512) */
	jizen_error_file2							TEXT NOT NULL,							/* 117.事前エラー添付ファイル２(512) */
	jizen_error_file3							TEXT NOT NULL,							/* 118.事前エラー添付ファイル３(512) */
	jizen_error_file1_hash						TEXT NOT NULL,							/* 119.事前エラー添付ファイル１（ハッシュ値）(512) */
	jizen_error_file2_hash						TEXT NOT NULL,							/* 120.事前エラー添付ファイル２（ハッシュ値）(512) */
	jizen_error_file3_hash						TEXT NOT NULL,							/* 121.事前エラー添付ファイル３（ハッシュ値）(512) */
	answer_request_no							TEXT NOT NULL,							/* 122.回答依頼番号(15) */
	qr_sakusei_flag								TEXT NOT NULL,							/* 123.QR作成フラグ(1) */
	nyukinope_tekiyo_kana						TEXT NOT NULL,							/* 124.入金オペ用摘要カナ入力欄(48) */
	tokki_ran									TEXT NOT NULL,							/* 125.特記欄(500) */
	syunougaku									NUMERIC(6) NOT NULL,					/* 126.収納額(6) */
	shimuke_bank_name_15						TEXT NOT NULL,							/* 127.＜１５桁＞仕向銀行名(15) */
	shimuke_shiten_name_15						TEXT NOT NULL,							/* 128.＜１５桁＞仕向支店名(15) */
	daiko_keiyaku_kbn_sel						TEXT NOT NULL,							/* 129.代行契約区分（選択時）(2) */
	kyuyo_flag_sel								TEXT NOT NULL,							/* 130.給与フラグ（選択時）(1) */
	eigyobuten_sel								TEXT NOT NULL,							/* 131.営業部店（選択時）(4) */
	tyouhyou_id									TEXT NOT NULL,							/* 132.帳票ID(2) */
	torihikiten_name							TEXT NOT NULL,							/* 133.取引店名(13) */
	torihikiten_name_kana						TEXT NOT NULL,							/* 134.取引店名（カナ）(15) */
	jimukanri_btn_name							TEXT NOT NULL,							/* 135.事務管理部店名(13) */
	jimukanri_btn_name_kana						TEXT NOT NULL,							/* 136.事務管理部店名（カナ）(15) */
	yokin_kamoku_name1							TEXT NOT NULL,							/* 137.預金科目名１(6) */
	yokin_kamoku_name2							TEXT NOT NULL,							/* 138.預金科目名２(6) */
	yokin_kamoku_name3							TEXT NOT NULL,							/* 139.預金科目名３(6) */
	furikae_tatenken_umu_flag_name1				TEXT NOT NULL,							/* 140.振替他店券有無フラグ名(2) */
	funo_jiyu_name								TEXT NOT NULL,							/* 141.不能事由名(34) */
	uchiwake_kamoku_name						TEXT NOT NULL,							/* 142.内訳科目名(34) */
	fuwatari_name								TEXT NOT NULL,							/* 143.不渡名(10) */
	keshikomi_kbn_name							TEXT NOT NULL,							/* 144.消込区分名(4) */
	jushin_message								TEXT NOT NULL,							/* 145.受信票メッセージ(48) */
	uchiwake_kamoku_name2						TEXT NOT NULL,							/* 146.内訳科目名２(28) */
	uchiwake_kamoku_name3						TEXT NOT NULL,							/* 147.内訳科目名３(28) */
	torikeshi_saisyutsuryoku					TEXT NOT NULL,							/* 148.取消_再出力(40) */
	kubun_jushin_no_kubun						TEXT NOT NULL,							/* 149.区分_受信番号_区分(10) */
	daiko_soushin_ten_no						TEXT NOT NULL,							/* 150.代行送信店番号(6) */
	daiko_soushin_buten_name					TEXT NOT NULL,							/* 151.代行送信店番号_部店名(15) */
	kisan_zenjitsu_date_d						TEXT NOT NULL,							/* 152.起算_前日日付_日付(4) */
	kisan_zenjitsu_date_ymd						TEXT NOT NULL,							/* 153.起算_前日日付_年月日(10) */
	kana_shumoku								TEXT NOT NULL,							/* 154.カナ種目(4) */
	kana_shumoku_shousai						TEXT NOT NULL,							/* 155.カナ種目_詳細(12) */
	tatenken_kingaku							TEXT NOT NULL,							/* 156.他店券金額(19) */
	chuki_1										TEXT NOT NULL,							/* 157.注記１(48) */
	chuki_2										TEXT NOT NULL,							/* 158.注記２(24) */
	tekiyo_tsushin								TEXT NOT NULL,							/* 159.摘要_通信(48) */
	kensu										TEXT NOT NULL,							/* 160.件数(7) */
	naiyo										TEXT NOT NULL,							/* 161.内容(16) */
	qr_irainin_name								TEXT NOT NULL,							/* 162.[QR]依頼人名(120) */
	qr_cif										TEXT NOT NULL,							/* 163.[QR]CIF(10) */
	qr_daiko_keiyaku_kbn						TEXT NOT NULL,							/* 164.[QR]代行契約区分(1) */
	qr_torihikisaki_name						TEXT NOT NULL,							/* 165.[QR]取引先名(120) */
	qr_biko										TEXT NOT NULL,							/* 166.[QR]備考(400) */
	qr_tesuryo_shuno_kbn						TEXT NOT NULL,							/* 167.[QR]手数料収納区分(1) */
	qr_kobetsu_info								TEXT NOT NULL,							/* 168.[QR]個別情報(60) */
	qr_tesuryo_biko								TEXT NOT NULL,							/* 169.[QR]手数料備考(20) */
	qr_nyukin_koza_shumoku						TEXT NOT NULL,							/* 170.[QR]入金口座種目(1) */
	qr_nyukin_koza_no							TEXT NOT NULL,							/* 171.[QR]入金口座番号(7) */
	qr_kitei_tesuryo							NUMERIC(6) NOT NULL,					/* 172.[QR]規定手数料(6) */
	shokansha_id								TEXT NOT NULL,							/* 173.初鑑者ID(8) */
	saikansha_id								TEXT NOT NULL,							/* 174.再鑑者ID(8) */
	kaito_shokansha_id							TEXT NOT NULL,							/* 175.回答初鑑者ID(8) */
	kaito_saikansha_id							TEXT NOT NULL,							/* 176.回答再鑑者ID(8) */
	update_user_id								VARCHAR(8),								/* 177.更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,	/* 178.システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL	/* 179.システム更新日時(17) */
);
COMMENT ON TABLE jushinhyo_table IS '受信票テーブル';
CREATE INDEX idx_kawase_shokai_no_15 ON jushinhyo_table (kawase_shokai_no_15);
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：受信票メッセージテーブル（jushin_message_table）
//  概要          ：受信票のメッセージを管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jushin_message_table;
CREATE TABLE jushin_message_table (
	jushin_message_code							VARCHAR(9) PRIMARY KEY,					/* 受信票メッセージコード(9) */
	jushin_message								TEXT,									/* 受信票メッセージ(38) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE jushin_message_table IS '受信票メッセージテーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：受信票履歴テーブル（jushinhyo_rireki_table）
//  概要		：受信票履歴を管理するテーブル
//  更新日時	：2025/05/02 14:00→2025/05/13 11:53 花田がカラムをそろえて直しました。
//  			  2025/07/2  13:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.25反映
//  			  2025/07/11 11:00 【為替不能管理システム】詳細設計書_x_データベース設計_Rev1.28反映
//                2025/07/29 データベース設計Rev1.32対応
//                2025/08/08 データベース設計Rev1.34対応
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jushinhyo_rireki_table;
CREATE TABLE jushinhyo_rireki_table (
	numbering_key								VARCHAR(15),							/* 1.ナンバリングキー(15) */
	edaban										INTEGER,								/* 2.枝番(2) */
	insert_date_time							DATE,									/* 3.登録日時(14) */
	jushin_renkei_data_ichiren_no_7				TEXT NOT NULL,							/* 4.受信票連携データ格納＜７桁＞一連番号(7) */
	shori_taisho_entity_code					TEXT NOT NULL,							/* 5.処理対象エンティティ識別コード(4) */
	torihiki_code								TEXT NOT NULL,							/* 6.取引識別コード(8) */
	shohin_service_code							TEXT NOT NULL,							/* 7.商品サービスコード(10) */
	delayed_logical_path_id_no					TEXT NOT NULL,							/* 8.ディレイド論理パスＩＤ番号(3) */
	delayed_logical_path_tsu_no					TEXT NOT NULL,							/* 9.ディレイド論理パス通番(15) */
	toriatsukai_date							DATE,									/* 10.取扱年月日(8) */
	toriatsukai_time							TEXT NOT NULL,							/* 11.取扱時刻(9) */
	delayed_seizon_message_info_code			TEXT NOT NULL,							/* 12.ディレイド生存通知メッセージ情報コード(1) */
	delayed_keihyo_output_buten_code			TEXT NOT NULL,							/* 13.ディレイド計表出力先事務管理部店コード(6) */
	jushin_insatsu_yusen_hiyusen_flag			TEXT NOT NULL,							/* 14.受信票印刷優先／非優先フラグ(2) */
	konai_terminal_message_id_no				TEXT NOT NULL,							/* 15.行内業務端末宛メッセージＩＤ番号(9) */
	tsushin_shumoku_code_4						TEXT NOT NULL,							/* 16.＜４桁＞通信種目コード(4) */
	jushin_sai_output_flag						TEXT NOT NULL,							/* 17.受信票再出力有無フラグ(1) */
	zengin_kurikoshi_hyoji						TEXT NOT NULL,							/* 18.全銀繰越表示(1) */
	zenjitsu_saisou_flag						TEXT NOT NULL,							/* 19.前日再送フラグ(1) */
	kawase_jushin_no_15							TEXT NOT NULL,							/* 20.＜１５桁＞為替受信番号(15) */
	jushinten_code_4							TEXT NOT NULL,							/* 21.＜４桁＞受信店コード(4) */
	jushinten_torihiki_ten_hojo_code			TEXT NOT NULL,							/* 22.受信店取引店補助コード(2) */
	jiten_jushin_output_buten_code				TEXT NOT NULL,							/* 23.自店受信票出力先事務管理部店コード(6) */
	denbun_jushin_date							DATE,									/* 24.電文受信年月日(8) */
	denbun_jushin_time_9						TEXT NOT NULL,							/* 25.＜９桁＞電文受信時刻(9) */
	shimuke_bank_code_4							TEXT NOT NULL,							/* 26.＜４桁＞仕向銀行コード(4) */
	kana_shimuke_bank_name_15					TEXT NOT NULL,							/* 27.＜１５桁＞カナ仕向銀行名(15) */
	shimuke_shiten_code_4						TEXT NOT NULL,							/* 28.＜４桁＞仕向支店コード(4) */
	kana_shimuke_shiten_name_15					TEXT NOT NULL,							/* 29.＜１５桁＞カナ仕向支店名(15) */
	naitame_output_terminal_buten_code			TEXT NOT NULL,							/* 30.＜内為出力＞端末設定事務管理部店コード(6) */
	jimu_kanri_buten_code						TEXT NOT NULL,							/* 31.事務管理部店コード(6) */
	naitame_torihiki_date						DATE,									/* 32.内為取引年月日(8) */
	tsushin_shumoku_code_42						TEXT NOT NULL,							/* 33.＜４桁＞通信種目コード2(4) */
	kawase_fuka_code							TEXT NOT NULL,							/* 34.＜為替＞付加コード(3) */
	naitame_torihiki_kingaku					NUMERIC(15) NOT NULL,					/* 35.内為取引金額(15) */
	zenjitsu_flag								TEXT NOT NULL,							/* 36.前日フラグ(1) */
	kisan_flag									TEXT NOT NULL,							/* 37.起算フラグ(1) */
	kanjo_date									DATE,									/* 38.勘定日(8) */
	kisan_date									DATE,									/* 39.起算日(8) */
	nyukinsaki_yokin_kamoku_code				TEXT NOT NULL,							/* 40.入金先預金科目コード(3) */
	nyukinsaki_koza_no							TEXT NOT NULL,							/* 41.入金先口座番号(7) */
	dai1_kana_tekiyo_info_48					TEXT NOT NULL,							/* 42.第１＜４８桁＞カナ摘要情報(48) */
	dai2_kana_tekiyo_info_48					TEXT NOT NULL,							/* 43.第２＜４８桁＞カナ摘要情報(48) */
	dai3_kana_tekiyo_info_48					TEXT NOT NULL,							/* 44.第３＜４８桁＞カナ摘要情報(48) */
	dai4_kana_tekiyo_info_48					TEXT NOT NULL,							/* 45.第４＜４８桁＞カナ摘要情報(48) */
	kana_edi_info_20							TEXT NOT NULL,							/* 46.＜２０桁＞カナＥＤＩ情報(20) */
	oguchi_uketuke_num_15						TEXT NOT NULL,							/* 47.＜半角英数／１５桁＞大口受付番号(15) */
	tsushin_shumokubetsu_no_info				TEXT NOT NULL,							/* 48.通信種目別番号情報(16) */
	furikae_tatenken_umu_flag					TEXT NOT NULL,							/* 49.振替他店券有無フラグ(1) */
	dai1_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 50.第１振替他店券入金額(18) */
	dai2_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 51.第２振替他店券入金額(18) */
	dai3_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 52.第３振替他店券入金額(18) */
	dai4_furikae_tatenken_nyukin_kingaku		NUMERIC(18,3) NOT NULL,					/* 53.第４振替他店券入金額(18) */
	rendou_nyukin_flag							TEXT NOT NULL,							/* 54.連動入金フラグ(1) */
	nyukin_funo_jiyu_code_2						TEXT NOT NULL,							/* 55.＜２桁＞入金不能事由コード(2) */
	torihiki_seigen_code_6						TEXT NOT NULL,							/* 56.＜６桁＞取引制限コード(6) */
	naitame_master_tsuchi_flag					TEXT NOT NULL,							/* 57.内為マスター通知通知要フラグ(1) */
	koza_kana_meiginin_name						TEXT NOT NULL,							/* 58.口座カナ名義人名(48) */
	kawase_hasshin_no_15						TEXT NOT NULL,							/* 59.＜１５桁＞為替発信番号(15) */
	kawase_shokai_no_15							TEXT NOT NULL,							/* 60.＜１５桁＞為替照会番号(15) */
	zengin_center_shori_time					TEXT NOT NULL,							/* 61.全銀センター処理時刻(6) */
	zengin_center_shori_no						TEXT NOT NULL,							/* 62.全銀センター処理番号(8) */
	kawase_hirendou_ko_no						TEXT NOT NULL,							/* 63.為替非連動口番号(7) */
	mokuteki_betsudan_meisai_no					TEXT NOT NULL,							/* 64.目的別別段明細番号(10) */
	chukan_kanjo_no								TEXT NOT NULL,							/* 65.中間勘定番号(10) */
	kawase_torihiki_soshin_op_id_no				TEXT NOT NULL,							/* 66.為替取引送信オペレーターＩＤ番号(10) */
	hishimuke_ten_code_4						TEXT NOT NULL,							/* 67.＜４桁＞被仕向店コード(4) */
	kana_hishimuke_ten_name_15					TEXT NOT NULL,							/* 68.＜１５桁＞カナ被仕向店名(15) */
	furikomi_uketorinin_yokin_kamoku_code		TEXT NOT NULL,							/* 69.振込受取人預金科目コード(3) */
	koza_no_15									TEXT NOT NULL,							/* 70.＜１５桁＞口座番号(15) */
	kasoten_hasshin_no_15						TEXT NOT NULL,							/* 71.仮想店＜１５桁＞発信番号(15) */
	kasoten_tensou_shimuke_bank_code_4			TEXT NOT NULL,							/* 72.仮想店転送情報＜４桁＞仕向銀行コード(4) */
	kasoten_tensou_kana_shimuke_bank_name_15	TEXT NOT NULL,							/* 73.仮想店転送情報＜１５桁＞カナ仕向銀行名(15) */
	kasoten_tensou_shimuke_ten_code_4			TEXT NOT NULL,							/* 74.仮想店転送情報＜４桁＞仕向店コード(4) */
	kasoten_tensou_kana_shimuke_ten_name_15		TEXT NOT NULL,							/* 75.仮想店転送情報＜１５桁＞カナ仕向店名(15) */
	saifurikomi_naitame_kamoku_code				TEXT NOT NULL,							/* 76.再振込元電文内為科目コード(3) */
	saifurikomi_koza_no_7						TEXT NOT NULL,							/* 77.再振込元電文＜英数字／７桁＞口座番号(7) */
	kawase_toritate_no_6						TEXT NOT NULL,							/* 78.＜為替＞＜６桁＞取立番号(6) */
	fuwatari_code_1								TEXT NOT NULL,							/* 79.＜１桁＞不渡コード(1) */
	shikin_shurui_code							TEXT NOT NULL,							/* 80.資金種類コード(5) */
	furikomihyo_tegata_kensu					TEXT NOT NULL,							/* 81.振込票／手形件数(5) */
	torikumi_no_6								TEXT NOT NULL,							/* 82.＜半角英数／６桁＞取組番号(6) */
	jushin_henshu_kubun_code					TEXT NOT NULL,							/* 83.受信票編集区分コード(1) */
	naitame_tsushin_torihiki_kingaku			TEXT NOT NULL,							/* 84.内為通信取引金額(15) */
	denbun_keshikomi_jokyo_code					TEXT NOT NULL,							/* 85.電文消込状況コード(1) */
	gyomu_error_code							TEXT NOT NULL,							/* 86.業務エラーコード(9) */
	oguchi_naitame_torikeshi_flag				TEXT NOT NULL,							/* 87.大口内為取消フラグ(1) */
	jushin_zengin_error_gyomu_error_code		TEXT NOT NULL,							/* 88.受信票全銀エラー固有部業務エラーコード(9) */
	kana_zengin_format_meisai_info_1			TEXT NOT NULL,							/* 89.＜１行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_2			TEXT NOT NULL,							/* 90.＜２行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_3			TEXT NOT NULL,							/* 91.＜３行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_4			TEXT NOT NULL,							/* 92.＜４行目＞カナ全銀フォーマット明細情報(48) */
	kana_zengin_format_meisai_info_9			TEXT NOT NULL,							/* 93.＜９行目＞カナ全銀フォーマット明細情報(48) */
	shiwa_kbn									TEXT NOT NULL,							/* 94.仕分区分(1) */
	syori_kbn_code								TEXT NOT NULL,							/* 95.処理区分コード(2) */
	status_code									TEXT NOT NULL,							/* 96.ステータスコード(2) */
	op_miss_kakuninyou_flag						TEXT NOT NULL,							/* 97.オペミス確認要フラグ(1) */
	op_miss_kakuninzumi_flag					TEXT NOT NULL,							/* 98.オペミス確認済フラグ(1) */
	kyuyo_flag									TEXT NOT NULL,							/* 99.給与フラグ(1) */
	yusen_flag									TEXT NOT NULL,							/* 100.優先フラグ(1) */
	fubi_flag									TEXT NOT NULL,							/* 101.不備フラグ(1) */
	ireitorihiki_flag							TEXT NOT NULL,							/* 102.異例取引フラグ(1) */
	tekiyo_1_moto								TEXT NOT NULL,							/* 103.摘要１元(48) */
	tekiyo_2_moto								TEXT NOT NULL,							/* 104.摘要２元(48) */
	tekiyo_3_moto								TEXT NOT NULL,							/* 105.摘要３元(48) */
	tekiyo_4_moto								TEXT NOT NULL,							/* 106.摘要４元(48) */
	shokai_no_moto								TEXT NOT NULL,							/* 107.照会番号元(15) */
	kanri_no_moto_tuke							TEXT NOT NULL,							/* 108.管理番号元-付替(512) */
	kanri_no_moto_haki							TEXT NOT NULL,							/* 109.管理番号元-破棄(512) */
	renrakujiko1								TEXT NOT NULL,							/* 110.連絡事項①(100) */
	renrakujiko2								TEXT NOT NULL,							/* 111.連絡事項②(50) */
	eigyobuten									TEXT NOT NULL,							/* 112.営業部店(4) */
	irainin_name_kana							TEXT NOT NULL,							/* 113.依頼人名（カナ）(48) */
	torihikisaki_no								VARCHAR(11) NOT NULL,					/* 114.取引先番号(11) */
	cifsaki_torihikisaki_no						VARCHAR(11) NOT NULL,					/* 115.CIF先取引先番号(11) */
	kaito_iraisyo_syurui						TEXT NOT NULL,							/* 116.回答依頼書種類(1) */
	jizen_error_file1							TEXT NOT NULL,							/* 117.事前エラー添付ファイル１(512) */
	jizen_error_file2							TEXT NOT NULL,							/* 118.事前エラー添付ファイル２(512) */
	jizen_error_file3							TEXT NOT NULL,							/* 119.事前エラー添付ファイル３(512) */
	jizen_error_file1_hash						TEXT NOT NULL,							/* 120.事前エラー添付ファイル１（ハッシュ値）(512) */
	jizen_error_file2_hash						TEXT NOT NULL,							/* 121.事前エラー添付ファイル２（ハッシュ値）(512) */
	jizen_error_file3_hash						TEXT NOT NULL,							/* 122.事前エラー添付ファイル３（ハッシュ値）(512) */
	answer_request_no							TEXT NOT NULL,							/* 123.回答依頼番号(15) */
	qr_sakusei_flag								TEXT NOT NULL,							/* 124.QR作成フラグ(1) */
	nyukinope_tekiyo_kana						TEXT NOT NULL,							/* 125.入金オペ用摘要カナ入力欄(48) */
	tokki_ran									TEXT NOT NULL,							/* 126.特記欄(500) */
	syunougaku									NUMERIC(6) NOT NULL,					/* 127.収納額(6) */
	shimuke_bank_name_15						TEXT NOT NULL,							/* 128.＜１５桁＞仕向銀行名(15) */
	shimuke_shiten_name_15						TEXT NOT NULL,							/* 129.＜１５桁＞仕向支店名(15) */
	daiko_keiyaku_kbn_sel						TEXT NOT NULL,							/* 130.代行契約区分（選択時）(2) */
	kyuyo_flag_sel								TEXT NOT NULL,							/* 131.給与フラグ（選択時）(1) */
	eigyobuten_sel								TEXT NOT NULL,							/* 132.営業部店（選択時）(4) */
	tyouhyou_id									TEXT NOT NULL,							/* 133.帳票ID(2) */
	torihikiten_name							TEXT NOT NULL,							/* 134.取引店名(13) */
	torihikiten_name_kana						TEXT NOT NULL,							/* 135.取引店名（カナ）(15) */
	jimukanri_btn_name							TEXT NOT NULL,							/* 136.事務管理部店名(13) */
	jimukanri_btn_name_kana						TEXT NOT NULL,							/* 137.事務管理部店名（カナ）(15) */
	yokin_kamoku_name1							TEXT NOT NULL,							/* 138.預金科目名１(6) */
	yokin_kamoku_name2							TEXT NOT NULL,							/* 139.預金科目名２(6) */
	yokin_kamoku_name3							TEXT NOT NULL,							/* 140.預金科目名３(6) */
	furikae_tatenken_umu_flag_name1				TEXT NOT NULL,							/* 141.振替他店券有無フラグ名(2) */
	funo_jiyu_name								TEXT NOT NULL,							/* 142.不能事由名(34) */
	uchiwake_kamoku_name						TEXT NOT NULL,							/* 143.内訳科目名(34) */
	fuwatari_name								TEXT NOT NULL,							/* 144.不渡名(10) */
	keshikomi_kbn_name							TEXT NOT NULL,							/* 145.消込区分名(4) */
	jushin_message								TEXT NOT NULL,							/* 146.受信票メッセージ(48) */
	uchiwake_kamoku_name2						TEXT NOT NULL,							/* 147.内訳科目名２(28) */
	uchiwake_kamoku_name3						TEXT NOT NULL,							/* 148.内訳科目名３(28) */
	torikeshi_saisyutsuryoku					TEXT NOT NULL,							/* 149.取消_再出力(40) */
	kubun_jushin_no_kubun						TEXT NOT NULL,							/* 150.区分_受信番号_区分(10) */
	daiko_soushin_ten_no						TEXT NOT NULL,							/* 151.代行送信店番号(6) */
	daiko_soushin_buten_name					TEXT NOT NULL,							/* 152.代行送信店番号_部店名(15) */
	kisan_zenjitsu_date_d						TEXT NOT NULL,							/* 153.起算_前日日付_日付(4) */
	kisan_zenjitsu_date_ymd						TEXT NOT NULL,							/* 154.起算_前日日付_年月日(10) */
	kana_shumoku								TEXT NOT NULL,							/* 155.カナ種目(4) */
	kana_shumoku_shousai						TEXT NOT NULL,							/* 156.カナ種目_詳細(12) */
	tatenken_kingaku							TEXT NOT NULL,							/* 157.他店券金額(19) */
	chuki_1										TEXT NOT NULL,							/* 158.注記１(48) */
	chuki_2										TEXT NOT NULL,							/* 159.注記２(24) */
	tekiyo_tsushin								TEXT NOT NULL,							/* 160.摘要_通信(48) */
	kensu										TEXT NOT NULL,							/* 161.件数(7) */
	naiyo										TEXT NOT NULL,							/* 162.内容(16) */
	qr_irainin_name								TEXT NOT NULL,							/* 163.[QR]依頼人名(120) */
	qr_cif										TEXT NOT NULL,							/* 164.[QR]CIF(10) */
	qr_daiko_keiyaku_kbn						TEXT NOT NULL,							/* 165.[QR]代行契約区分(1) */
	qr_torihikisaki_name						TEXT NOT NULL,							/* 166.[QR]取引先名(120) */
	qr_biko										TEXT NOT NULL,							/* 167.[QR]備考(400) */
	qr_tesuryo_shuno_kbn						TEXT NOT NULL,							/* 168.[QR]手数料収納区分(1) */
	qr_kobetsu_info								TEXT NOT NULL,							/* 169.[QR]個別情報(60) */
	qr_tesuryo_biko								TEXT NOT NULL,							/* 170.[QR]手数料備考(20) */
	qr_nyukin_koza_shumoku						TEXT NOT NULL,							/* 171.[QR]入金口座種目(3) */
	qr_nyukin_koza_no							TEXT NOT NULL,							/* 172.[QR]入金口座番号(7) */
	qr_kitei_tesuryo							NUMERIC(6) NOT NULL,					/* 173.[[QR]規定手数料(6) */
	shokansha_id								TEXT NOT NULL,							/* 174.初鑑者ID(8) */
	saikansha_id								TEXT NOT NULL,							/* 175.再鑑者ID(8) */
	kaito_shokansha_id							TEXT NOT NULL,							/* 176.回答初鑑者ID(8) */
	kaito_saikansha_id							TEXT NOT NULL,							/* 177.回答再鑑者ID(8) */
	rireki_update_user_id						VARCHAR(8) NOT NULL,					/* 178.更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,	/* 179.システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,	/* 180.システム更新日時(17) */
	CONSTRAINT jushinhyo_rireki_table_pkc PRIMARY KEY (numbering_key, edaban)
);
COMMENT ON TABLE jushinhyo_rireki_table IS '受信票履歴テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：消費税テーブル（shohizei_table）
//  概要          ：消費税率を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS shohizei_table;
CREATE TABLE shohizei_table (
	tekiyo_kaishi_date							DATE PRIMARY KEY,						/* 適応開始日(10) */
	shohizei_ritsu								NUMERIC(4, 1),							/* 消費税率(5) */
	update_user_id								VARCHAR(8),								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE shohizei_table IS '消費税テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：照会電文消込区分テーブル（syoukai_denbun_keshikomi_kbn_table）
//  概要          ：照会電文消込区分を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS syoukai_denbun_keshikomi_kbn_table;
CREATE TABLE syoukai_denbun_keshikomi_kbn_table (
    keshikomi_kbn_code							VARCHAR(1) PRIMARY KEY,					/* 消込区分コード(1) */
    keshikomi_kbn_name1							TEXT,									/* 消込区分名１(4) */
    keshikomi_kbn_name2							TEXT,									/* 消込区分名２(512) */
    keshikomi_kbn_name3							TEXT,									/* 消込区分名３(512) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE syoukai_denbun_keshikomi_kbn_table IS '照会電文消込区分テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：操作ログテーブル（log_table）
//  概要          ：操作ログを保存するテーブル
//  更新日時      ：2025/05/21→2025/06/27 花田が修正しました（num_keyの配列）。
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS log_table;
CREATE TABLE log_table (
    log_id										VARCHAR(36),							/* ID(36) */
    center_no									VARCHAR(6),								/* センター番号 */
    log_level									VARCHAR(10),							/* ログレベル(10) */
    operation_date_time							TIMESTAMP,								/* 操作日時(8) */
    term_id										TEXT,									/* 機番(256) */
    user_id										TEXT,									/* ユーザID(8) */
    user_name									TEXT,									/* ユーザ名(32) */
    num_key										VARCHAR(15)[],							/* 管理番号(15) */
    type										TEXT,									/* 種類(10) */
    message										TEXT,									/* メッセージ(120) */
    gamen_taisho_flag							TEXT,									/* 操作ログ画面対象フラグ("0"：対象外、"1"：対象)(1) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
    CONSTRAINT log_table_pkc PRIMARY KEY (log_id, center_no)
);
COMMENT ON TABLE log_table IS '操作ログテーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：他店券有無情報テーブル（tatenken_umu_info_table）
//  概要          ：他店券有無情報を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS tatenken_umu_info_table;
CREATE TABLE tatenken_umu_info_table (
    furikae_tatenken_umu_flag					VARCHAR(1) PRIMARY KEY,					/* 振替他店券有無フラグ(1) */
    furikae_tatenken_umu_flag_name1				TEXT,									/* 振替他店券有無フラグ名１(2) */
    furikae_tatenken_umu_flag_name2				TEXT,									/* 振替他店券有無フラグ名２(512) */
    furikae_tatenken_umu_flag_name3				TEXT,									/* 振替他店券有無フラグ名３(512) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE tatenken_umu_info_table IS '他店券有無情報テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：通信種目テーブル（tsushin_shumoku_table）
//  概要          ：通信種目を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS tsushin_shumoku_table;
CREATE TABLE IF NOT EXISTS tsushin_shumoku_table (
	tsushin_shumoku_code_4						VARCHAR(4) PRIMARY KEY,					/* 通信種目コード(4) */
	tsushin_shumoku_name1						TEXT,									/* 通信種目名1(4) */
	tsushin_shumoku_name2						TEXT,									/* 通信種目名2(12) */
	tsushin_shumoku_name3						TEXT,									/* 通信種目名3(48) */
	tyouhyou_id									TEXT,									/* 帳票ID(2) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE tsushin_shumoku_table IS '通信種目テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：添付ファイル情報テーブル（tmp_file_jyouhou_table）
//  概要          ：添付ファイル情報を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS tmp_file_jyouhou_table;
CREATE TABLE tmp_file_jyouhou_table (
	tmp_file_no									VARCHAR(36),							/* 添付ファイル番号(36) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	mail_soujyushin_no							VARCHAR(36),							/* メール送受信番号(36) */
	tmp_file_path								TEXT,									/* ファイルパス(512) */
	file_name									TEXT,									/* ファイル名(512) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT tmp_file_jyouhou_table_pkc PRIMARY KEY (tmp_file_no, center_no)
);
COMMENT ON TABLE tmp_file_jyouhou_table IS '添付ファイル情報テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：内訳科目名（内為）テーブル（uchiwake_kamoku）
//  概要          ：内訳科目名（内為）を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS uchiwake_kamoku_table;
CREATE TABLE uchiwake_kamoku_table (
    uchiwake_kamoku_code						VARCHAR(7) PRIMARY KEY,					/* 内訳科目コード(7) */
    uchiwake_kamoku_name1						TEXT,									/* 内訳科目名１(20) */
    uchiwake_kamoku_name2						TEXT,									/* 内訳科目名２(34) */
    uchiwake_kamoku_name3						TEXT,									/* 内訳科目名３(20) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE uchiwake_kamoku_table IS '内訳科目名（内為）テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：不渡コードテーブル（fuwatari_code_table）
//  概要          ：不渡コードを管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS fuwatari_code_table;
CREATE TABLE fuwatari_code_table (
    fuwatari_code								VARCHAR(2) PRIMARY KEY,					/* 不渡コード(1) */
    fuwatari_name1								TEXT,									/* 不渡名１(10) */
    fuwatari_name2								TEXT,									/* 不渡名２(512) */
    fuwatari_name3								TEXT,									/* 不渡名３(512) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE fuwatari_code_table IS '不渡コードテーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：不能事由テーブル（funo_jiyu_table）
//  概要          ：不能事由を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS funo_jiyu_table;
CREATE TABLE funo_jiyu_table (
    funo_jiyu_code								VARCHAR(2) PRIMARY KEY,					/* 不能事由コード(2) */
    funo_jiyu_name1								TEXT,									/* 不能事由名１(34) */
    funo_jiyu_name2								TEXT,									/* 不能事由名２(512) */
    funo_jiyu_name3								TEXT,									/* 不能事由名３(512) */
    system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
    system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE funo_jiyu_table IS '不能事由テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：預金科目テーブル（yokin_kamoku_table）
//  概要          ：預金科目を管理するテーブル
//  更新日時      ：2025/05/21
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS yokin_kamoku_table;
CREATE TABLE yokin_kamoku_table (
	kamoku_code									VARCHAR(3) PRIMARY KEY,					/* 科目コード(3) */
	kamoku_name1								TEXT,									/* 科目名１(512) */
	kamoku_name2								TEXT,									/* 科目名２(6) */
	kamoku_name3								TEXT,									/* 科目名３(512) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP		/* システム更新日時(17) */
);
COMMENT ON TABLE yokin_kamoku_table IS '預金科目テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：事務管理部店テーブル（jimukanri_btn_table）
//  概要		：事務管理部店を管理するテーブル
//  更新日時	：2025/05/21削除
//                2025/09/29 データベース設計Rev1.38対応で復活
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jimukanri_btn_table;
CREATE TABLE jimukanri_btn_table(
	jimukanri_btn_cd			text PRIMARY KEY,							/* 取引店コード(6) */
	jimukanri_btn_name 			text,										/* 取引店名(13) */
	jimukanri_btn_name_kana		text,										/* 取引店名（カナ）(15) */
	system_insert_datetime 		timestamp 		DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime 		timestamp 		DEFAULT CURRENT_TIMESTAMP	/* システム更新日時(17) */
);
COMMENT ON TABLE jimukanri_btn_table IS '事務管理部店テーブル';

/* シーケンサ */
DROP SEQUENCE answer_request_seq;
CREATE SEQUENCE answer_request_seq
  start with 1
  increment by 1
  minvalue 0;

DROP SEQUENCE torihikisaki_seq;
CREATE SEQUENCE torihikisaki_seq
  start with 1
  increment by 1
  minvalue 0;
