/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：状況一括更新依頼テーブル（sotsu_tantosha_table）
//  概要		：状況一括更新依頼を管理するテーブル
//  更新日時	：2025/10/27 14:30
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jokyo_ikkatsu_koushin_table;
CREATE TABLE jokyo_ikkatsu_koushin_table (
	torihikisaki_no								TEXT,									/* 取引先番号(11) */
	tantosha_id									INTEGER,								/* 担当者ID(14) */
	hontoroku_kubun								VARCHAR(1),								/* 本登録区分(1) */
	to_atesaki									TEXT,									/* To(宛先)(1) */
	tantosha_name								TEXT,									/* 担当者氏名(120) */
	tantosha_name_kana							TEXT,									/* 担当者氏名（カナ）(120) */
	tantosha_tel_no								TEXT,									/* 担当者電話番号(16) */
	mail_address								TEXT,									/* メールアドレス(50) */
	soshin_test_status							TEXT,									/* 送信テストステータス(10) */
	delete_date									DATE,									/* 削除日(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT jokyo_ikkatsu_koushin_table_pkc PRIMARY KEY (torihikisaki_no, tantosha_id, hontoroku_kubun)
);
COMMENT ON TABLE jokyo_ikkatsu_koushin_table IS '状況一括更新依頼テーブル';
