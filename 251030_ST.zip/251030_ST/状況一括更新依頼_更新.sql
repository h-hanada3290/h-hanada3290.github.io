UPDATE
	torihikisaki_tantosha_table as ttn
SET
	soshin_test_status = jik.soshin_test_status
FROM
	jokyo_ikkatsu_koushin_table as jik
WHERE
	ttn.torihikisaki_no = jik.torihikisaki_no
AND ttn.tantosha_id = jik.tantosha_id
AND ttn.hontoroku_kubun = jik.hontoroku_kubun;
/* ---------------------------------------------------------------------------------------------------------------------------------- */
SELECT
	COUNT(*)
FROM
	torihikisaki_tantosha_table as ttn
INNER JOIN
	jokyo_ikkatsu_koushin_table as jik
ON
	ttn.torihikisaki_no = jik.torihikisaki_no
AND ttn.tantosha_id = jik.tantosha_id
AND ttn.hontoroku_kubun = jik.hontoroku_kubun;
/* ---------------------------------------------------------------------------------------------------------------------------------- */
SELECT
	*
FROM
	torihikisaki_tantosha_table as ttn
INNER JOIN
	jokyo_ikkatsu_koushin_table as jik
ON
	ttn.torihikisaki_no = jik.torihikisaki_no
AND ttn.tantosha_id = jik.tantosha_id
AND ttn.hontoroku_kubun = jik.hontoroku_kubun;
/* ---------------------------------------------------------------------------------------------------------------------------------- */
/* �����S���҃e�[�u���̍X�V���� */
SELECT
	ttn.torihikisaki_no,
	ttn.tantosha_id,
	ttn.hontoroku_kubun,
	ttn.soshin_test_status
FROM
	torihikisaki_tantosha_table as ttn
INNER JOIN
	jokyo_ikkatsu_koushin_table as jik
ON
	ttn.torihikisaki_no = jik.torihikisaki_no
AND ttn.tantosha_id = jik.tantosha_id
AND ttn.hontoroku_kubun = jik.hontoroku_kubun;
/* ---------------------------------------------------------------------------------------------------------------------------------- */
/* �󋵈ꊇ�X�V�˗��f�[�^�̃��N�G�X�g���e */
SELECT
	jik.torihikisaki_no,
	jik.tantosha_id,
	jik.hontoroku_kubun,
	jik.soshin_test_status
FROM
	torihikisaki_tantosha_table as ttn
INNER JOIN
	jokyo_ikkatsu_koushin_table as jik
ON
	ttn.torihikisaki_no = jik.torihikisaki_no
AND ttn.tantosha_id = jik.tantosha_id
AND ttn.hontoroku_kubun = jik.hontoroku_kubun;
/* ---------------------------------------------------------------------------------------------------------------------------------- */