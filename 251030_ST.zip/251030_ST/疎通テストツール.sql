/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：受信ファイル管理テーブル（jyushin_file_table）
//  概要		：受信ファイルを管理するテーブル
//  更新日時	：2025/10/27 14:30
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS jyushin_file_table;
CREATE TABLE jyushin_file_table(
	tmp_id serial PRIMARY KEY,
	soujyushin_id varchar,
	mail_address text,
	tmp_file_path text,
	file_name text,
	system_insert_datetime timestamp DEFAULT CURRENT_TIMESTAMP ,
	system_update_datetime timestamp DEFAULT CURRENT_TIMESTAMP 
);
COMMENT ON TABLE jyushin_file_table IS '受信ファイル管理テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：送受信管理テーブル（mail_table）
//  概要		：メール送受信を管理するテーブル
//  更新日時	：2025/10/27 14:30
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS mail_table;
CREATE TABLE mail_table(
	soujyushin_id text PRIMARY KEY,
	torihikisaki_no varchar,
	tantosha_id int,
	status text,
	soujyushin_time timestamp,
	soushin_count int DEFAULT 0,
	soushin_fail_count int DEFAULT 0,
	jyushin_to text,
	jyushin_cc text,
	jyushin_title text,
	jyushin_honbun text,
	jyushin_soushinsha text,
	jyushin_mail_id text,
	biko text,
	system_insert_datetime timestamp DEFAULT CURRENT_TIMESTAMP ,
	system_update_datetime timestamp DEFAULT CURRENT_TIMESTAMP 
);
COMMENT ON TABLE mail_table IS '送受信管理テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名    ：メール内容テーブル（sotsu_mail_template_table）
//  概要          ：メール内容を管理するテーブル
//  更新日時	：2025/10/27 14:30
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS sotsu_mail_template_table;
CREATE TABLE sotsu_mail_template_table (
	mail_naiyo_no							VARCHAR(6) PRIMARY KEY,						/* メール内容番号(6) */
	gyomu									TEXT,										/* 業務(2) */
	center_no								VARCHAR(6),									/* センター番号(6) */
	syori_kbn_code							TEXT,										/* 処理区分コード(2) */
	mail_title								TEXT,										/* 件名(64) */
	honbun									TEXT,										/* 本文(500) */
	template_1								TEXT,										/* テンプレート１(500) */
	template_2								TEXT,										/* テンプレート２(500) */
	template_3								TEXT,										/* テンプレート３(500) */
	template_4								TEXT,										/* テンプレート４(500) */
	template_5								TEXT,										/* テンプレート５(500) */
	template_6								TEXT,										/* テンプレート６(500) */
	template_7								TEXT,										/* テンプレート７(500) */
	template_8								TEXT,										/* テンプレート８(500) */
	template_9								TEXT,										/* テンプレート９(500) */
	template_10								TEXT,										/* テンプレート１０(500) */
	template_11								TEXT,										/* テンプレート１１(500) */
	template_12								TEXT,										/* テンプレート１２(500) */
	template_13								TEXT,										/* テンプレート１３(500) */
	template_14								TEXT,										/* テンプレート１４(500) */
	system_insert_datetime					TIMESTAMP DEFAULT CURRENT_TIMESTAMP,		/* システム登録日時(17) */
	system_update_datetime					TIMESTAMP DEFAULT CURRENT_TIMESTAMP			/* システム更新日時(17) */
);
COMMENT ON TABLE sotsu_mail_template_table IS '疎通テスト用メール内容テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：取引先情報テーブル（sotsu_torihikisaki_table）
//  概要		：取引先を管理するテーブル
//  更新日時	：2025/10/27 14:30
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS sotsu_torihikisaki_table;
CREATE TABLE sotsu_torihikisaki_table (
	torihikisaki_no								VARCHAR(11),							/* 取引先番号(11) */
	hontoroku_kubun								VARCHAR(1),								/* 本登録区分(1) */
	kaishi_date									DATE,									/* 開始日(8) */
	uketsuke_date								DATE,									/* 受付日(8) */
	torihikisaki_status							TEXT,									/* 取引先ステータス(2) */
	torihikisaki_name							TEXT,									/* 取引先名(120) */
	center_no									VARCHAR(6),								/* センター番号(6) */
	eigyo_buten_code							TEXT,									/* 営業部店コード(4) */
	cif											TEXT,									/* CIF(10) */
	furikomi_kbn								TEXT,									/* 振込区分(8) */
	jiko_tsugou_kbn								TEXT,									/* 自己都合区分(2) */
	tokushu_atsuka_saki							TEXT,									/* 特殊扱先(1) */
	tesuryo_shuno_kbn							TEXT,									/* 手数料収納区分(1) */
	henko_tesuryo								INTEGER,								/* 変更手数料(6) */
	henko_tesuryo_biko							TEXT,									/* 変更手数料備考(20) */
	kumimodoshi_tesuryo_koza_henkyaku			INTEGER,								/* 組戻手数料（口座返却）(6) */
	kumimodoshi_tesuryo_koza_henkyaku_biko		TEXT,									/* 組戻手数料（口座返却）(20)備考 */
	kumimodoshi_tesuryo_sai_furikomi			INTEGER,								/* 組戻手数料（再振込）(6) */
	kumimodoshi_tesuryo_sai_furikomi_biko		TEXT,									/* 組戻手数料（再振込）(20)備考 */
	nyukin_koza_shumoku							TEXT,									/* 入金口座種目(3) */
	nyukin_koza_no								TEXT,									/* 入金口座番号(7) */
	daihyo_tel_no								TEXT,									/* 代表電話番号(16) */
	daiko_keiyaku_kbn							TEXT,									/* 代行契約区分(32) */
	daiko_keiyaku_moto							TEXT,									/* 代行契約元(11) */
	irainin_name_kana							TEXT,									/* 依頼人名（カナ）(48) */
	chui_kanki_level							TEXT,									/* 注意喚起レベル(1) */
	tempu_file_password							TEXT,									/* 添付ファイルパスワード(24) */
	biko										TEXT,									/* 備考(400) */
	delete_date									DATE,									/* 削除日(8) */
	update_user_id								VARCHAR(8),								/* 添付ファイル作成フラグ(2) */
	tmp_file_flag								TEXT,								/* 更新ユーザID(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT sotsu_torihikisaki_table_pkc PRIMARY KEY (torihikisaki_no, hontoroku_kubun)
);
COMMENT ON TABLE sotsu_torihikisaki_table IS '疎通テスト用取引先情報テーブル';
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  テーブル名	：取引先担当者テーブル（sotsu_tantosha_table）
//  概要		：取引先担当者を管理するテーブル
//  更新日時	：2025/10/27 14:30
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
DROP TABLE IF EXISTS sotsu_tantosha_table;
CREATE TABLE sotsu_tantosha_table (
	torihikisaki_no								TEXT,									/* 取引先番号(11) */
	tantosha_id									INTEGER,								/* 担当者ID(14) */
	hontoroku_kubun								VARCHAR(1),								/* 本登録区分(1) */
	to_atesaki									TEXT,									/* To(宛先)(1) */
	tantosha_name								TEXT,									/* 担当者氏名(120) */
	tantosha_name_kana							TEXT,									/* 担当者氏名（カナ）(120) */
	tantosha_tel_no								TEXT,									/* 担当者電話番号(16) */
	mail_address								TEXT,									/* メールアドレス(50) */
	soshin_test_status							TEXT,									/* 送信テストステータス(10) */
	delete_date									DATE,									/* 削除日(8) */
	system_insert_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム登録日時(17) */
	system_update_datetime						TIMESTAMP DEFAULT CURRENT_TIMESTAMP,	/* システム更新日時(17) */
	CONSTRAINT sotsu_tantosha_table_pkc PRIMARY KEY (torihikisaki_no, tantosha_id, hontoroku_kubun)
);
COMMENT ON TABLE sotsu_tantosha_table IS '疎通テスト用取引先担当者テーブル';
