--------------------------------------------------------------------------------
-- public.sessions のレイアウト変更
--   注意！！：テーブルに依存するオブジェクト（ビューなど）が削除される場合があります。それらのオブジェクトは復元されません。
--   2025/09/16 h_hanada
--------------------------------------------------------------------------------


-- 新テーブルの作成
create table public."$$sessions" (
  id serial not null
  , session_id character varying(255)
  , data bytea
  , expiry timestamp(6) without time zone
)
/


-- 新テーブルへデータ投入
insert into public."$$sessions"(id, session_id, data, expiry)
  select org.id, org.session_id, org.data, org.expiry from public.sessions org
/


-- 元テーブルの削除
drop table public.sessions cascade
/


-- 新テーブルをリネームして元テーブル名に変更
alter table public."$$sessions" rename to sessions
/

alter sequence public."$$sessions_id_seq" rename to sessions_id_seq
/


-- インデックスとユニーク制約の作成
create unique index sessions_session_id_key on public.sessions(session_id)
/

alter table public.sessions add constraint sessions_session_id_key unique (session_id)
/


-- 主キーの作成
alter table public.sessions  add constraint sessions_pkey primary key (id)
/


-- コメントの作成
comment on table public.sessions is ''
/

comment on column public.sessions.id is ''
/

comment on column public.sessions.session_id is ''
/

comment on column public.sessions.data is ''
/

comment on column public.sessions.expiry is ''
/


-- その他のDDL
grant DELETE on public.sessions to "postgres"
/

grant INSERT on public.sessions to "postgres"
/

grant REFERENCES on public.sessions to "postgres"
/

grant SELECT on public.sessions to "postgres"
/

grant TRIGGER on public.sessions to "postgres"
/

grant TRUNCATE on public.sessions to "postgres"
/

grant UPDATE on public.sessions to "postgres"
/

grant INSERT ("data") on public.sessions to "postgres"
/

grant REFERENCES ("data") on public.sessions to "postgres"
/

grant SELECT ("data") on public.sessions to "postgres"
/

grant UPDATE ("data") on public.sessions to "postgres"
/

grant INSERT ("expiry") on public.sessions to "postgres"
/

grant REFERENCES ("expiry") on public.sessions to "postgres"
/

grant SELECT ("expiry") on public.sessions to "postgres"
/

grant UPDATE ("expiry") on public.sessions to "postgres"
/

grant INSERT ("id") on public.sessions to "postgres"
/

grant REFERENCES ("id") on public.sessions to "postgres"
/

grant SELECT ("id") on public.sessions to "postgres"
/

grant UPDATE ("id") on public.sessions to "postgres"
/

grant INSERT ("session_id") on public.sessions to "postgres"
/

grant REFERENCES ("session_id") on public.sessions to "postgres"
/

grant SELECT ("session_id") on public.sessions to "postgres"
/

grant UPDATE ("session_id") on public.sessions to "postgres"
/


-- 新しいセッションコピーテーブルを作成します
create table public.sessions_copy (
  id bigint not null,
  session_id character varying(255),
  data bytea,
  expiry timestamp(6) without time zone
);

-- sessionsテーブルからsessions_copyテーブルにデータをコピーします
insert into public.sessions_copy (id, session_id, data, expiry)
select id, session_id, data, expiry
from public."$$sessions";

-- コピーが完了したことを確認します
select count(*) from public.sessions_copy;
-- ----------------------------------------------------------------------------
-- 新しいセッションコピーテーブルを作成します
create table sessions_copy (
  id bigint not null,
  session_id character varying(255),
  data bytea,
  expiry timestamp(6) without time zone
);

-- sessionsテーブルからsessions_copyテーブルにデータをコピーします
insert into sessions_copy (id, session_id, data, expiry)
select id, session_id, data, expiry
from sessions;

-- コピーが完了したことを確認します
select count(*) from sessions_copy;
-- ----------------------------------------------------------------------------






