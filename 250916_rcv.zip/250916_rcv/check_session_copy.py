import psycopg2
import msgpack
import json
import os

# 仮のDB接続情報。実際の環境に合わせて変更してください。
# DB_HOST = os.environ.get("DB_HOST", "localhost")
# DB_NAME = os.environ.get("DB_NAME", "your_db_name")
# DB_USER = os.environ.get("DB_USER", "your_user")
# DB_PASSWORD = os.environ.get("DB_PASSWORD", "your_password")

DB_HOST = "localhost"
DB_NAME = "postgres"
DB_USER = "postgres"
DB_PASSWORD = ""

def get_db_connection():
    """データベースに接続します。"""
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            options="-c timezone=UTC"
        )
        return conn
    except psycopg2.OperationalError as e:
        print(f"データベース接続エラー: {e}")
        return None

def find_locks_in_db():
    """
    sessions_copyテーブルからセッションデータを読み込み、
    'locks'情報を抽出して表示します。
    """
    conn = get_db_connection()
    if conn is None:
        return

    try:
        with conn.cursor() as cur:
            # sessions_copyテーブルからすべてのデータを取得
            cur.execute("SELECT session_id, data FROM sessions_copy;")
            results = cur.fetchall()

            if not results:
                print("sessions_copyテーブルにデータがありません。")
                return

            for row in results:
                session_id, session_data_bytes = row
                
                # データ型が'memoryview'の場合、bytes型に変換
                if isinstance(session_data_bytes, memoryview):
                    session_data_bytes = bytes(session_data_bytes)
                
                if not session_data_bytes:
                    continue

                try:
                    # msgpackでデコード
                    session_dict = msgpack.unpackb(session_data_bytes, raw=False)
                    
                    if 'locks' in session_dict:
                        print(f"--- セッションID {session_id} のロック情報 ---")
                        print(json.dumps(session_dict['locks'], indent=2, ensure_ascii=False))
                        print("-" * 20)
                    else:
                        print(f"--- セッションID {session_id} にロック情報が見つかりませんでした ---")
                
                except Exception as e:
                    print(f"セッションデータのデコードエラー (セッションID: {session_id}): {e}")

    except Exception as e:
        print(f"予期せぬエラーが発生しました: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    find_locks_in_db()

"""
eof

### 実行方法

1.  **`psycopg2`のインストール**:
    * このスクリプトはPostgreSQLデータベースに接続するため、`psycopg2`ライブラリが必要です。まだインストールしていない場合は、以下のコマンドでインストールしてください。
      ```bash
      pip install psycopg2-binary
      ```
2.  **DB接続情報の修正**:
    * スクリプト上部の`DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`を、ご自身のデータベース環境に合わせて修正してください。
3.  **実行**:
    * スクリプトを`check_sessions_from_db.py`として保存し、以下のコマンドで実行します。
      ```bash
      python check_sessions_from_db.py
      
"""